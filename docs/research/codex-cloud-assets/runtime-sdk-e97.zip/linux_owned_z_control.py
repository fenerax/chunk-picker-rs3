"""Linux real-pidfd control for selected actual guard functions; no app imports."""
import ast, json, os, pathlib, select, subprocess, sys
guard = pathlib.Path(sys.argv[1])
names = {'ZombieObservation','stat_fields','status_fields','cpuset','checked',
         'read_identity','same_generation','sample_owned','acquire_owned'}
tree = ast.parse(guard.read_text())
nodes = [n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names]
assert len(nodes) == len(names)
root = pathlib.Path('/proc')
env = {'ROOT':root,'json':json,'os':os}
exec(compile(ast.Module(body=nodes,type_ignores=[]),'actual-guard-functions', 'exec'),env)
mask = set(sorted(os.sched_getaffinity(0))[:2]); assert len(mask)==2
os.sched_setaffinity(0,mask)
assert env['stat_fields']((root/'self/stat').read_text())['pid'] == os.getpid()
namespace = os.readlink(root/'self/ns/pid')
child = subprocess.Popen([sys.executable,'-B','-c','import time; time.sleep(1); raise SystemExit(7)'])
fd = None
result = {'scope':'harmless real owned-process terminal proof, not product'}
try:
    read = lambda pid: env['read_identity'](pid,mask,namespace)
    alive = lambda descriptor: not select.select([descriptor],[],[],0)[0]
    before = read(child.pid)
    def owner(row):
        assert row['pid']==child.pid and row['ppid']==os.getpid()
        assert row['pgrp']==os.getpgrp()
    fd = env['acquire_owned'](before,before,os.pidfd_open,read,alive,owner,os.close,0)
    assert alive(fd)
    assert select.select([fd],[],[],3)[0], 'child terminal deadline'
    try:
        read(child.pid)
    except env['ZombieObservation'] as error:
        terminal = error.row
        assert terminal['pid']==child.pid and terminal['start']==before['start']
        assert terminal['state']=='Z' and terminal['rss']>=0
    else:
        raise AssertionError('expected unreaped terminal child')
    assert env['sample_owned'](child.pid,before['start'],fd,read,
                              lambda descriptor:not alive(descriptor)) is None
    result.update(pid=child.pid,start=before['start'],namespace=namespace,cpus=sorted(mask),
                  stateBefore=before['state'],stateAfter=terminal['state'],
                  actualStatRss=terminal['rss'],terminalRss=None,
                  pidfdReadable=True,ownedSampleReturnedNone=True,exitCodeBeforeWait=None)
    code=child.wait(timeout=3); assert code==7
    result.update(childWaitCode=code,reapedStatAbsent=not (root/str(child.pid)/'stat').exists())
    assert result['reapedStatAbsent']
finally:
    if child.returncode is None:
        child.wait(timeout=4)
    if fd is not None: os.close(fd)
print(json.dumps(result,separators=(',',':')))


"""Linux research guard. Prototype: root review + cloud dummy smoke REQUIRED."""
import errno, json, os, pathlib, select, signal, subprocess, sys, time

ROOT = pathlib.Path('/proc')
RSS_CAP = 6 * 1024**3
OUTPUT_CAP, LEDGER_CAP = 1024**2, 8 * 1024**2
INTERVAL = .25


class ZombieObservation(RuntimeError):
    def __init__(self, row, message):
        super().__init__(message)
        self.row = row


def stat_fields(text):
    left, right = text.index('('), text.rindex(')')
    pid, fields = int(text[:left].strip()), text[right + 1:].split()
    if len(fields) < 22 or pid <= 0:
        raise ValueError('invalid stat')
    return dict(pid=pid, state=fields[0], ppid=int(fields[1]),
                start=int(fields[19]), rss=int(fields[21]), pgrp=int(fields[2]))


def status_fields(text):
    return dict(line.split(':', 1) for line in text.splitlines() if ':' in line)


def cpuset(text):
    result = set()
    for part in text.strip().split(','):
        span = part.split('-')
        a, b = int(span[0]), int(span[-1])
        if len(span) > 2 or a < 0 or b < a or b > 65535:
            raise ValueError('invalid CPU list')
        result.update(range(a, b + 1))
    if not result:
        raise ValueError('empty CPU list')
    return result


def checked(row, status, expected, mask, affinity, namespace, expected_ns, allowZombie=False):
    if row['pid'] != expected or int(status['Pid']) != expected or int(status['Tgid']) != expected:
        raise RuntimeError('PID/proc-view mismatch')
    if namespace != expected_ns or not row['start'] > 0:
        raise RuntimeError('namespace/starttime mismatch')
    if cpuset(status['Cpus_allowed_list']) != mask or set(affinity) != mask:
        raise RuntimeError('affinity mismatch or unknown')
    if (row['state'] == 'Z' and not allowZombie) or row['rss'] < 0:
        message = 'zombie or negative RSS observation: ' + json.dumps({
            'requestedPID': expected, 'row': {key: row.get(key) for key in ('pid', 'state', 'ppid', 'start', 'rss', 'pgrp')},
            'status': {key: status.get(key) for key in ('State', 'VmRSS', 'Pid', 'Tgid')},
            'namespace': namespace, 'expectedNamespace': expected_ns,
            'actualAffinity': sorted(affinity), 'expectedAffinity': sorted(mask)})
        if row['state'] == 'Z' and row['rss'] >= 0 and not allowZombie:
            raise ZombieObservation(row, message)
        raise RuntimeError(message)
    return row


def read_identity(pid, mask, namespace, allowZombie=False):
    base = ROOT / str(pid)
    row = stat_fields((base / 'stat').read_text())
    checked(row, status_fields((base / 'status').read_text()), pid, mask,
            os.sched_getaffinity(pid), os.readlink(base / 'ns/pid'), namespace, allowZombie)
    if row['state'] != 'Z':
        tasks = list((base / 'task').iterdir())
        if not 1 <= len(tasks) <= 512:
            raise RuntimeError('thread inventory bound')
        for task in tasks:
            status = status_fields((task / 'status').read_text())
            if int(status['Pid']) != int(task.name) or int(status['Tgid']) != pid:
                raise RuntimeError('thread identity mismatch')
            if cpuset(status['Cpus_allowed_list']) != mask or set(os.sched_getaffinity(int(task.name))) != mask:
                raise RuntimeError('thread affinity mismatch')
        if row['rss'] < 0:
            raise RuntimeError('negative live RSS')
    end = stat_fields((base / 'stat').read_text())
    if (end['pid'], end['start']) != (pid, row['start']):
        raise RuntimeError('identity changed during read')
    row['rssBytes'] = row['rss'] * os.sysconf('SC_PAGE_SIZE') if row['state'] != 'Z' else None
    return row


def discover_rows(root):
    rows, vanished = {}, 0
    for entry in root.iterdir():
        if not entry.name.isdecimal(): continue
        try:
            row = stat_fields((entry / 'stat').read_text())
        except OSError as error:
            if error.errno != errno.ENOENT: raise
            vanished += 1
            continue
        if row['pid'] != int(entry.name): raise RuntimeError('discovery proc-view mismatch')
        rows[row['pid']] = row
    return rows, vanished


def descendants(rows, owned):
    found = set(owned)
    while True:
        new = found | {pid for pid, row in rows.items() if row['ppid'] in found}
        if new == found:
            return found
        found = new


def same_generation(known, row):
    if known is not None and known != row['start']:
        raise RuntimeError('owned PID reused')


def sample_owned(pid, start, fd, read_row, exited_fd):
    try:
        return read_row(pid)
    except ZombieObservation as error:
        # checked() already validated PID/TGID/ns/affinity/nonnegative RSS.
        if error.row['pid'] != pid: raise RuntimeError('owned zombie PID mismatch')
        same_generation(start, error.row)
        if not exited_fd(fd): raise  # A zombie leader alone does not prove group exit.
        return None  # Exit proof, never synthetic zero RSS or a claimed exit code.


def acquire_owned(row, discovered, open_fd, read_row, alive, ownership, close_fd, retained_count):
    # Enforce retained-generation capacity BEFORE opening any candidate fd.
    if not 0 <= retained_count < 128: raise RuntimeError('retained generation capacity')
    # Uncommitted descriptors MUST NEVER enter the cleanup/signaling map.
    if discovered['pid'] != row['pid']: raise RuntimeError('discovery PID mismatch')
    same_generation(discovered['start'], row)
    temporary = open_fd(row['pid'])
    try:
        if not alive(temporary): raise RuntimeError('acquired process already exited')
        after = read_row(row['pid'])
        if after['pid'] != row['pid']: raise RuntimeError('acquired PID mismatch')
        same_generation(row['start'], after); same_generation(discovered['start'], after)
        ownership(after)
        if not alive(temporary): raise RuntimeError('process exited before ownership commit')
        return temporary
    except BaseException:
        close_fd(temporary)
        raise



def terminal_not_owned(discovered, read_terminal, open_fd, readable, prove_parent, close_fd):
    # Process pidfd (flags=0): readability must prove whole thread-group exit.
    keys = ('pid', 'start', 'ppid', 'pgrp', 'state')
    def matching(row):
        if discovered['state'] != 'Z' or discovered['rss'] < 0 or row['state'] != 'Z':
            raise RuntimeError('terminal discovery is not a valid zombie observation')
        if tuple(row[key] for key in keys) != tuple(discovered[key] for key in keys):
            raise RuntimeError('terminal discovery identity changed')
    before = read_terminal(discovered['pid']); matching(before); prove_parent(before)
    temporary = open_fd(before['pid'])
    try:
        if not readable(temporary): raise RuntimeError('terminal thread-group exit unproven')
        after = read_terminal(before['pid']); matching(after); prove_parent(after)
        if not readable(temporary): raise RuntimeError('terminal thread-group exit changed')
        return after
    finally:
        close_fd(temporary)  # Never returned, committed, signaled or retained.


def barrier(read_fd, write_fd, command):
    # No product exec until parent independently validates this same PID.
    signal.alarm(10)
    row = stat_fields((ROOT / 'self/stat').read_text())
    if row['pid'] != os.getpid() or os.readlink(ROOT / 'self') != str(os.getpid()):
        raise RuntimeError('child self/proc mapping mismatch')
    hello = dict(pid=os.getpid(), start=row['start'], ns=os.readlink(ROOT / 'self/ns/pid'))
    os.write(write_fd, (json.dumps(hello) + '\n').encode()); os.close(write_fd)
    if os.read(read_fd, 1) != b'G':
        raise RuntimeError('exec permission absent')
    os.close(read_fd); signal.alarm(0)
    os.execvp(command[0], command)


def run(directory, seconds, command):
    if not 0 < seconds <= 1200 or not command:
        raise ValueError('wall cap must be (0,1200], command required')
    directory = pathlib.Path(directory); directory.mkdir(exist_ok=False)
    ledger = (directory / 'events.ndjson').open('xb')
    output = (directory / 'product-output.log').open('xb')
    ledger_bytes = 0
    def record(event, **values):
        nonlocal ledger_bytes
        data = (json.dumps(dict(event=event, monotonic=time.monotonic(), **values)) + '\n').encode()
        if ledger_bytes + len(data) > LEDGER_CAP:
            raise RuntimeError('ledger output cap')
        if ledger.write(data) != len(data): raise RuntimeError('short ledger write')
        ledger.flush(); os.fsync(ledger.fileno()); ledger_bytes += len(data)
    child = None; owned = {}; pidfds = {}; exited = set(); failure = None; product_start = None; code = None
    release_r = release_w = hello_r = hello_w = None
    started = time.monotonic()
    def interrupted(signum, frame): raise RuntimeError(f'guard signal {signum}')
    signal.signal(signal.SIGTERM, interrupted); signal.signal(signal.SIGINT, interrupted)
    try:
        if not hasattr(os, 'pidfd_open') or not hasattr(signal, 'pidfd_send_signal'):
            raise RuntimeError('pidfd identity/exit/cleanup APIs required')
        mask = set(sorted(os.sched_getaffinity(0))[:2])
        if len(mask) != 2:
            raise RuntimeError('two allowed CPUs unavailable')
        os.sched_setaffinity(0, mask)  # before child creation; inherited across exec
        if stat_fields((ROOT / 'self/stat').read_text())['pid'] != os.getpid() or os.readlink(ROOT / 'self') != str(os.getpid()):
            raise RuntimeError('guard self/proc mapping mismatch')
        namespace = os.readlink(ROOT / 'self/ns/pid')
        control = read_identity(os.getpid(), mask, namespace)
        record('control', identity=control, namespace=namespace, cpus=sorted(mask),
               productRssExcludesControl=True, sampledPeakOnly=True)
        release_r, release_w = os.pipe(); hello_r, hello_w = os.pipe()
        child = subprocess.Popen([sys.executable, __file__, '--barrier', str(release_r), str(hello_w), *command],
            pass_fds=(release_r, hello_w), start_new_session=True, stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        os.close(release_r); release_r = None; os.close(hello_w); hello_w = None
        if not select.select([hello_r], [], [], 8)[0]:
            raise RuntimeError('barrier hello deadline')
        hello = json.loads(os.read(hello_r, 4096)); os.close(hello_r); hello_r = None
        row = read_identity(child.pid, mask, namespace)
        if hello != dict(pid=child.pid, start=row['start'], ns=namespace) or row['ppid'] != os.getpid() or row['state'] == 'Z':
            raise RuntimeError('barrier PID/start/namespace/parent mismatch')
        if row['rssBytes'] > RSS_CAP: raise RuntimeError('pre-exec RSS exceeded 6GiB')
        alive = lambda fd: not select.select([fd], [], [], 0)[0]
        read_owned = lambda pid: read_identity(pid, mask, namespace)
        def barrier_owner(current):
            if current['pid'] != child.pid or current['ppid'] != os.getpid() or current['pgrp'] != child.pid:
                raise RuntimeError('barrier ownership changed')
        fd = acquire_owned(row, row, os.pidfd_open, read_owned, alive, barrier_owner, os.close, len(owned))
        owned[child.pid] = row['start']; pidfds[child.pid] = fd
        record('pre-exec-verified', child=row, hello=hello)
        product_start = time.monotonic(); os.write(release_w, b'G'); os.close(release_w); release_w = None
        record('exec-release', pid=child.pid, wallCapSeconds=seconds)
        os.set_blocking(child.stdout.fileno(), False)
        output_bytes = 0
        def descendant_owner(current):
            candidates = [current['ppid']] if current['ppid'] in pidfds else list(pidfds)
            for ancestor in candidates:
                if not alive(pidfds[ancestor]): continue
                proof = read_owned(ancestor); same_generation(owned[ancestor], proof)
                if alive(pidfds[ancestor]) and (ancestor == current['ppid'] or proof['pgrp'] == current['pgrp'] == child.pid): return
            raise RuntimeError('current owned ancestry/group proof absent')
        def terminal_parent(current):
            parent = current['ppid']
            if parent not in pidfds or parent in exited or not alive(pidfds[parent]):
                raise RuntimeError('terminal direct owned parent is not live')
            proof = read_owned(parent); same_generation(owned[parent], proof)
            if proof['pid'] != parent or not alive(pidfds[parent]):
                raise RuntimeError('terminal direct owned parent changed or exited')
        while True:
            if time.monotonic() - product_start >= seconds or time.monotonic() - started >= seconds + 15:
                raise RuntimeError('monotonic deadline')
            # Vanished discovery candidates are not live samples or ownership.
            rows, vanished = discover_rows(ROOT)
            if vanished: record('discovery-vanished', count=vanished)
            for pid, fd in pidfds.items():
                if pid not in exited and select.select([fd], [], [], 0)[0]:
                    exited.add(pid); record('owned-exit-observed', pid=pid, start=owned[pid], proof='pidfd-readable', rssBytes=None)
            pids = descendants(rows, set(owned) - exited) | {pid for pid, row in rows.items() if row['pgrp'] == child.pid}
            for pid in pids & owned.keys():
                if pid in rows: same_generation(owned[pid], rows[pid])
            pids -= exited
            if len(pids) > 128:
                raise RuntimeError('owned process inventory bound')
            samples = []
            for pid in sorted(pids):
                if pid not in owned and rows[pid]['state'] == 'Z':
                    terminal = terminal_not_owned(rows[pid],
                        lambda candidate: read_identity(candidate, mask, namespace, allowZombie=True),
                        lambda candidate: os.pidfd_open(candidate, 0),
                        lambda descriptor: not alive(descriptor), terminal_parent, os.close)
                    record('terminal-not-owned', identity=terminal, namespace=namespace,
                           proof='process-pidfd-readable-twice', exitCode=None)
                    continue  # This generation only; no PID exclusion survives this iteration.
                row = sample_owned(pid, owned[pid], pidfds[pid], read_owned,
                    lambda descriptor: not alive(descriptor)) if pid in owned else read_identity(pid, mask, namespace)
                if row is None:
                    exited.add(pid)
                    record('owned-exit-observed', pid=pid, start=owned[pid], proof='pidfd-readable-after-validated-zombie',
                           rssBytes=None, exitCode=None)
                    continue
                same_generation(owned.get(pid), row)
                if pid not in owned:
                    fd = acquire_owned(row, rows[pid], os.pidfd_open, read_owned, alive, descendant_owner, os.close, len(owned))
                    owned[pid] = row['start']; pidfds[pid] = fd
                owned[pid] = row['start']; samples.append(row)
            rss = sum(row['rssBytes'] for row in samples if row['rssBytes'] is not None)
            record('sample', owned=samples, productRssBytes=rss if samples else None, activeCount=len(samples),
                   control=read_identity(os.getpid(), mask, namespace))
            if rss > RSS_CAP:
                raise RuntimeError('sampled aggregate RSS exceeded 6GiB')
            ready = select.select([child.stdout], [], [], INTERVAL)[0]
            if ready:
                data = os.read(child.stdout.fileno(), 65536)
                if output_bytes + len(data) > OUTPUT_CAP:
                    raise RuntimeError('product output cap')
                if output.write(data) != len(data): raise RuntimeError('short output write')
                output.flush(); output_bytes += len(data)
            code = child.poll()
            if code is not None:
                # Poll reaps direct child only after final identity/sample above.
                if any(pid != child.pid and pid not in exited for pid in owned):
                    raise RuntimeError('root exited with live owned descendants')
                while select.select([child.stdout], [], [], 0)[0]:
                    data = os.read(child.stdout.fileno(), 65536)
                    if not data: break
                    output_bytes += len(data)
                    if output_bytes > OUTPUT_CAP: raise RuntimeError('product output cap')
                    if output.write(data) != len(data): raise RuntimeError('short final output write')
                    output.flush()
                record('root-exit', code=code, confirmedExited=sorted(exited))
                break
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        try: record('failure', reason=failure, productReleased=product_start is not None)
        except BaseException: print('GUARD RECORD FAILURE: ' + failure, file=sys.stderr)
    finally:
        signal.signal(signal.SIGTERM, signal.SIG_IGN); signal.signal(signal.SIGINT, signal.SIG_IGN)
        for fd in (release_r, release_w, hello_r, hello_w):
            if fd is not None:
                try: os.close(fd)
                except OSError: pass
        if child is not None:
            if not pidfds:  # Unverified barrier shim only; never released to product.
                child.terminate()
                try: child.wait(timeout=2)
                except subprocess.TimeoutExpired: child.kill(); child.wait(timeout=2)
            # A group signal requires a still-owned, generation-verified member.
            for sig in (signal.SIGTERM, signal.SIGKILL):
                group_verified = False
                for pid, start in owned.items():
                    try:
                        if not alive(pidfds[pid]): continue
                        row = stat_fields((ROOT / str(pid) / 'stat').read_text())
                        same_generation(start, row)
                        if row['pid'] != pid: raise RuntimeError('cleanup PID mismatch')
                        group_verified |= alive(pidfds[pid]) and row['pgrp'] == child.pid
                    except FileNotFoundError: pass
                    except BaseException as error: failure = failure or f'cleanup identity: {error}'
                if group_verified:
                    try: os.killpg(child.pid, sig)
                    except ProcessLookupError: pass
                    except OSError as error: failure = failure or f'group cleanup: {error}'
                for fd in pidfds.values():
                    try: signal.pidfd_send_signal(fd, sig)
                    except ProcessLookupError: pass
                    except OSError as error: failure = failure or f'pidfd cleanup: {error}'
                try: child.wait(timeout=2)
                except subprocess.TimeoutExpired: failure = failure or 'cleanup wait deadline'
            if any(not select.select([fd], [], [], 0)[0] for fd in pidfds.values()):
                failure = failure or 'owned exit not confirmed after cleanup'
        try: record('terminal', failure=failure, rootCode=child.returncode if child else None, observedBeforeCleanupCode=code, released=product_start is not None,
                    ownedGenerations=owned, elapsed=time.monotonic() - started)
        except BaseException as error: failure = failure or f'terminal sink: {error}'
        for fd in pidfds.values(): os.close(fd)
        ledger.close(); output.close()
    return 1 if failure or code != 0 else 0


if __name__ == '__main__':
    if sys.argv[1:2] == ['--barrier']:
        barrier(int(sys.argv[2]), int(sys.argv[3]), sys.argv[4:])
    else:
        raise SystemExit(run(sys.argv[1], float(sys.argv[2]), sys.argv[3:]))

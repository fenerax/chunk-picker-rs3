"""Harmless root/owned-child lifecycle; child lives long enough for live samples."""
import json, subprocess, sys, time
child = subprocess.Popen([sys.executable,'-B','-c','import time; time.sleep(0.9); raise SystemExit(7)'])
time.sleep(1.7)
code = child.wait(timeout=2)
assert code==7
time.sleep(0.5)
print(json.dumps({'scope':'harmless whole-guard smoke','childPid':child.pid,'childWaitCode':code,'rootExpectedCode':0}))


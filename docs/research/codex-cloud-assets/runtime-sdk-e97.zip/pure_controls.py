"""Prepared NOT RUN: actual AST-selected source, fake identity and FD only."""
import ast, json
from pathlib import Path
source = Path(__file__).with_name('guard-candidate.py').read_text(encoding='utf-8')
names = {'ZombieObservation', 'checked', 'cpuset', 'same_generation', 'sample_owned'}
nodes = [n for n in ast.parse(source).body if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name in names]
assert len(nodes) == len(names)
env = {'json': json}
exec(compile(ast.Module(body=nodes, type_ignores=[]), 'actual-owned-z-recheck', 'exec'), env)
row = dict(pid=41, start=123, state='Z', rss=0, ppid=7, pgrp=7)
status = dict(Pid='41', Tgid='41', Cpus_allowed_list='0-1')
count = 0

def run(changes=None, status_changes=None, namespace='ns', affinity={0,1}, readable=True, known=123, error=None):
    polls = []
    def read(pid):
        assert pid == 41
        if error: raise error
        return env['checked']({**row, **(changes or {})}, {**status, **(status_changes or {})},
                              41, {0,1}, affinity, namespace, 'ns')
    def exited(fd): assert fd == 99; polls.append(fd); return readable
    return lambda: env['sample_owned'](41, known, 99, read, exited), polls

def failure(call, expected=Exception):
    try: call()
    except expected as error: return error
    raise AssertionError('failure expected')

call, polls = run(); assert call() is None and polls == [99]; count += 1
call, polls = run(changes={'state':'S', 'rss':5}); assert call()['rss'] == 5 and polls == []; count += 1
call, polls = run(readable=False); assert isinstance(failure(call), env['ZombieObservation']) and polls == [99]; count += 1
call, polls = run(known=999); failure(call, RuntimeError); assert polls == []; count += 1
for args in [dict(changes={'pid':42}), dict(changes={'start':0}), dict(changes={'rss':-1}),
             dict(status_changes={'Pid':'42'}), dict(status_changes={'Tgid':'42'}),
             dict(status_changes={'Cpus_allowed_list':'0'}), dict(namespace='other'), dict(affinity={0})]:
    call, polls = run(**args); error = failure(call)
    assert not isinstance(error, env['ZombieObservation']) and polls == []
    count += 1
for error in [FileNotFoundError('missing stat'), PermissionError('unreadable namespace'),
              KeyError('rss'), RuntimeError('thread identity mismatch'), RuntimeError('other failure')]:
    call, polls = run(error=error); assert failure(call) is error and polls == []; count += 1
call, polls = run(error=env['ZombieObservation']({**row, 'pid':42}, 'fake wrong PID'))
failure(call, RuntimeError); assert polls == []; count += 1
call, polls = run(changes={'state':'S', 'rss':0}); assert call()['rss'] == 0 and polls == []; count += 1
# Direct default identity behavior remains a RuntimeError rejection for Z.
call, _ = run();
try: env['checked'](row, status, 41, {0,1}, {0,1}, 'ns', 'ns')
except RuntimeError as error: assert isinstance(error, env['ZombieObservation'])
else: raise AssertionError('default zombie rejection relaxed')
count += 1
print(f'{count} pure owned-Z recheck controls passed; no guard import/proc/FD/spawn/signals')

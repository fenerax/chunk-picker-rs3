// Pure preparation checks only. Never import adapter.mjs: it imports Chromium.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createHash } from 'node:crypto';
import { validatePhaseConfig } from './phase-config.mjs';
import { createLedger } from './ledger.mjs';
const read = name => fs.readFileSync(new URL(name, import.meta.url));
const config = JSON.parse(read('./phase-config.json'));
assert.equal(config.startUtc, null, 'prepared template must remain unstamped');
assert.throws(() => validatePhaseConfig(config, 0), /phase-start-unset/);
const start = Date.parse('2026-10-22T23:00:00.000Z');
const stamped = { ...config, startUtc: '2026-10-22T23:00:00.000Z' };
assert(Object.isFrozen(validatePhaseConfig(stamped, start)));
assert.equal(validatePhaseConfig(stamped, start + 720000).dummyLimitMs, 120000);
for (const bad of [start - 1, start + 720001, NaN]) assert.throws(() => validatePhaseConfig(stamped, bad));
for (const patch of [{ attempts: 2 }, { preparationLimitMs: 720001 }, { dummyLimitMs: 120001 }, { extra: true }])
  assert.throws(() => validatePhaseConfig({ ...stamped, ...patch }, start));
assert.equal(createHash('sha256').update(read('./ledger.mjs')).digest('hex'),
  '5bad0bff91320fb3ebba510de124bdb98e611d8c1cda4de85e8fb9c9e2fd60c3');
const source = read('./adapter.mjs').toString();
const guard = source.indexOf('const phase=validatePhaseConfig(');
assert(guard > 0);
for (const token of ["fs.openSync('attempt.lock'", "fs.openSync('trace.ndjson'", 'http.createServer(', 'chromium.launchServer('])
  assert(source.indexOf(token) > guard, token + ' must follow guard');
assert(source.includes("fs.openSync('attempt.lock','wx'"));
assert(source.includes("flag:'wx'"));
assert(source.includes("['ignore','consume','cancel'].entries()"));
assert.equal((source.match(/await fetch\('\/api\/usage'/g) ?? []).length, 1);
assert(source.includes('writeAll(buffer,offset+n).then(resolve,reject)'));
assert(source.includes('process.exitCode=1;report.failure='));
assert(source.includes('process.exitCode=report.exitCode'));
assert(source.includes("report.cleanup.some(p=>p.sameProcess&&p.state!=='Z')"));
assert(source.includes("report.exitCode=invalid?1:report.preClose.status==='drained'?0:report.preClose.status==='not-drained'?2:1"));
assert(source.indexOf('report.drainStartedAt=now()') > source.indexOf("if(policy==='ignore')assert.equal(value.bodyUsed,false)"));
assert(source.indexOf("await record('pre-close'") < source.indexOf('closing=true;'));
const ledger = createLedger({ ownedOrigin: 'http://owned.invalid', expectedTargets: 3, maxEvents: 256,
  maxActive: 32, maxRecent: 64, maxSessions: 4, maxWrites: 64, maxDocumentsPerSession: 4,
  maxExpectedSsePerTarget: 0, sink() {} });
assert.equal(ledger.snapshot().counts.events, 0);
console.log('R46 preparation pure checks passed; template unstamped; adapter never imported; all body cases UNRUN.');

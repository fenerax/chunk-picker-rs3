# R46 preparation receipt — all policies UNRUN

Preparation only: no dispatch, adapter import, HTTP server, browser, policy execution, benchmark, product source edit, ledger change or GitHub action. R44 terminal state remains a prerequisite for root's later decision. This receipt authorizes no execution.

## Preserved inputs

- R45's only ordinary attempt ended before bind with EPERM; ignore/consume/cancel remain UNRUN. Its shell 0 was a caught-error reporting limitation, not a successful experiment.
- Original unexercised R45 adapter is unchanged: SHA-256 `392ab73c29c8f7e8fd040052fb853575e51b29ddb5d829a9df12c2a2c18e26a7`.
- `ledger.mjs` is a byte-identical copy of reviewed `5bad0bff91320fb3ebba510de124bdb98e611d8c1cda4de85e8fb9c9e2fd60c3` (12068 bytes). No core ledger redesign or exception was added.
- Historical R42 used cloud standard per-command `with_additional_permissions` with network enabled, not `require_escalated`. The earlier ordinary-only restriction was mistaken; this historical fact is metadata, not a runtime permission workaround or proof of EPERM causation.

## Minimal delta from R45

1. Replaced the hardcoded old preparation timestamp with a pure `phase-config.json` validator. The prepared template has `startUtc:null`. Root supplies one fresh start before actual cloud preparation, never refreshes it, and exclusively creates the separate execution config. Null/future/expired/altered contracts refuse before output or server/browser construction. Fixed limits remain 12-minute preparation, 120-second total externally guarded dummy attempt, one attempt, 3 GiB sampled RSS and initial two-CPU external guard.
2. Added exclusive output refusal and a permanent exclusive attempt lock; `result.json` now also uses `wx`. No prior phase artifacts may be overwritten or removed to retry. README separates template pure checks from a fresh execution subdirectory.
3. Changed ordinary-only metadata to state that the actual grant is not inferred by the adapter. README requires the cloud's own permitted scoped-grant workflow, stopping on any denial, with no policy/settings changes, `require_escalated` or review bypass. This changes no browser/network implementation.
4. Kept exactly three same-HTTP-200-JSON, same keepalive payload/evaluation-ownership cases. Added explicit assertions of status 200, ok, initially unused body, consume byte count/read completion, cancel completion, and ignore's unused body. Cancellation remains distinct from consumption and server-local finish. Changed the dummy page title to R46.
5. Added explicit final status and CLI exit codes: 0 valid complete/drained, 2 valid complete/not-drained, 1 operation/semantic/evidence/incomplete or cleanup failure. Caught failures immediately set nonzero. Sampled executable survivors, port/close failures and late `problem` flags cannot become green cleanup. Expected post-close coverage faults never rewrite the pre-close drain snapshot.
6. Left partial-write retries and fdatasync chain unchanged. Left server request-end, supplied-body byte, response finish/close/error and cumulative socket-byte receipts intact. Cumulative socket totals are not per-request delivered-body bytes.

The unchanged five-second drain starts after all three policy calls return and is never refreshed; the pre-close outcome is persisted before cleanup. The outer initial-affinity timeout must bound the entire dummy command to 115 seconds plus at most 5 seconds kill grace; internal await/check behavior alone is not a hard cap. No fourth case or retry is permitted. Fixed order, one page per policy, natural Response/GC lifetime, and general detach/navigation coverage remain limitations.

## Ordinary direct verification performed

Syntax checks passed for adapter.mjs, ledger.mjs, phase-config.mjs and prepared-selftest.mjs. The pure checker imported only Node built-ins, the validator and pure ledger; it did not import the adapter/Chromium and wrote no output. It verified the unstamped template, frozen contract/boundaries, ledger hash/constructor and source ordering/guards/assertion markers.

```text
R46 preparation pure checks passed; template unstamped; adapter never imported; all body cases UNRUN.
```

No attempt.lock, trace.ndjson, browser-stderr.txt or result.json was created. Syntax/source checks do not validate the browser/network branches; those remain unexercised.

## Exact prepared file hashes

| File | Bytes | SHA-256 |
|---|---:|---|
| adapter.mjs | 15814 | 1ca593444153e4a9ce2ce686f7cd55981f72d5855589aa73ee68531fee6fd085 |
| ledger.mjs | 12068 | 5bad0bff91320fb3ebba510de124bdb98e611d8c1cda4de85e8fb9c9e2fd60c3 |
| phase-config.json (unstamped template) | 138 | ec42676aa1b2b97cc1c5f9c7005ea02ffcb38c2e719dc25795e806871e5d7e41 |
| phase-config.mjs | 980 | 9c2feeb211a089ea7ce3dcfaf7a8d7b3480c95d7188d8c95b1d3086cbf9faa35 |
| prepared-selftest.mjs | 2901 | 4b8c2259f6ea9e1df67341d271f9fcd9885f1bf5aa22e19fca573dac45d6fe34 |
| README.md | 7478 | dc8530c021ea5af3d2eb6bfee8d58155754f0e7412c18a66aa26c4060f5d189c |

Root must record the separately stamped cloud config hash and actual grant/guard/runtime receipts if R46 is later dispatched. All R46 observation and body-policy conclusions remain absent.

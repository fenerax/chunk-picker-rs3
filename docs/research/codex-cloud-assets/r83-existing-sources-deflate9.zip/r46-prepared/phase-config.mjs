// Pure validation only: no clock reads, imports, writes, services or execution.
export function validatePhaseConfig(config, nowUtcMs) {
  const keys = ['schemaVersion', 'phase', 'startUtc', 'preparationLimitMs', 'dummyLimitMs', 'attempts'];
  if (!config || Object.keys(config).length !== keys.length || keys.some(k => !Object.hasOwn(config, k)) ||
    config.schemaVersion !== 1 || config.phase !== 'R46' || config.preparationLimitMs !== 720000 ||
    config.dummyLimitMs !== 120000 || config.attempts !== 1) throw Error('phase-config-contract');
  if (typeof config.startUtc !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/.test(config.startUtc))
    throw Error('phase-start-unset-or-invalid');
  const start = Date.parse(config.startUtc);
  if (!Number.isFinite(start) || !Number.isFinite(nowUtcMs) || nowUtcMs < start || nowUtcMs - start > config.preparationLimitMs)
    throw Error('phase-preparation-window');
  return Object.freeze({ ...config });
}

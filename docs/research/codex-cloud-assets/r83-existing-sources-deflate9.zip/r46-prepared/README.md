# R46 prepared only: three dummy body policies

Status: **UNEXECUTED, UNDISPATCHED, all three policies UNRUN**. Do not import or run `adapter.mjs` during preparation. It statically imports the installed Chromium/Playwright package even when the phase guard would refuse. Only syntax checks and the pure preparation checker below are authorized here. No picker source or ledger implementation changed.

R45's one ordinary `listen()` attempt ended in EPERM before binding or browser launch. Its caught failure returned shell 0; its persisted failure remains authoritative. This preparation provides no new explanation for EPERM or body behavior. R42 historically used cloud `with_additional_permissions` per-command scoped permissions with network enabled, not `require_escalated`. The old ordinary-only restriction was mistaken. R46 adapter metadata makes no claim about its actual future command grant.

## Dispatch prerequisites (root owns these)

Wait until R44 is terminal. Do not compete with its browser/process work. A later R46 requires explicit root dispatch through the cloud's own scoped-grant workflow, and only if active higher-priority policies permit. Stop on any denial; do not change policies/settings, bypass review, use `require_escalated`, or retry under another mechanism. The adapter contains no permission workaround.

At entry to the actual cloud phase, root records **one fresh UTC start before any phase preparation**, then never refreshes it. This local `phase-config.json` deliberately has `startUtc:null` and must remain an unstamped template. In a fresh cloud phase directory, create the stamped configuration once, exclusively, using that recorded start and the same remaining fixed values. Do not copy a null file and repeatedly overwrite/reset its clock. Preserve the phase-entry record and actual config hash. No existing phase/output file may be overwritten.

Use separate fresh template and execution subdirectories: run the ordinary syntax/pure gate against the unstamped template, then copy adapter/ledger/validator into a new execution directory and exclusively create its stamped config. The one phase-entry start predates both steps. This avoids overwriting the template to execute or refreshing a stamp after checking preparation.

The pure validator refuses a null, future, expired or altered contract. Adapter validation runs before output creation, attempt-lock creation, and HTTP/browser construction. Preparation must finish within 720000 ms (12 minutes) of the single root start. `attempt.lock` is created exclusively and never removed: exactly one attempt is permitted. An expired stamp, lock, existing output, bind refusal or browser failure ends this phase; all unobserved cases stay UNRUN. Prepare nothing by starting an HTTP/browser service.

## Mandatory ordinary direct checks

Use ordinary direct tool calls, no scoped permission argument needed for these reads/syntax/pure checks:

```text
node --check adapter.mjs
node --check ledger.mjs
node --check phase-config.mjs
node --check prepared-selftest.mjs
node prepared-selftest.mjs
```

The pure checker never imports the HTTP adapter or Chromium, writes no files and starts no service. It validates the unstamped template, finite preparation boundaries, fixed limits, unchanged ledger hash, constructor, source ordering, partial-write preservation, exactly three policies and exit-code contract. Run it against the unstamped prepared template before cloud config creation. It is a static/pure check, not proof that browser/network branches work.

## Future one-attempt execution bounds

Retain the installed runtime/browser identities. Pin the external timeout guard to CPUs 0-1 **before** it starts Node; the adapter checks both its parent guard and itself before constructing the server and samples all observed process/thread masks. Use a single outer termination guard with at most 115 seconds plus at most 5 seconds kill grace, so the entire dummy attempt is bounded by 120 seconds, including cleanup. For example, only in the separately authorized cloud dispatch:

```text
taskset -c 0,1 timeout --signal=TERM --kill-after=5s 115s <existing-node-path> adapter.mjs
```

The cloud command's allowed scoped grant is an execution-tool decision, not a Node flag or adapter setting. Record the actual grant receipt. No retry, install, upgrade, forced GC, CPU profile, fourth policy, broad matrix, product workload or soak follows. A 3 GiB sampled summed-RSS guard is unchanged; samples can miss peaks. The external 120-second guard is mandatory because awaited browser operations/cleanup can hang beyond internal checks. Preserve any partial evidence if it fires.

## Exact comparison and interpretation

There are exactly three fresh pages with one same-origin keepalive POST each: ignore, consume, cancel. All receive the same HTTP 200 JSON body `{"accepted":true}`, same payload, headers and async evaluation ownership. Responses remain local variables; evaluation returns scalar results, without deliberate global Response retention. No fourth case or policy retry exists. All page CDP listeners and Network.enable calls precede the first owned navigation.

The order is fixed and each policy has one page/observation. This is a bounded diagnostic comparison, not replicated causal evidence or a population tail claim; page/order effects and natural Response/GC lifetime remain limits.

Each policy requires HTTP 200/ok=true and an initially unused body. Consume explicitly awaits arrayBuffer and verifies its byte count/read completion. Cancel awaits body cancellation and records it separately; it is not successful body consumption. Ignore performs neither action and verifies bodyUsed remains false. BodyUsed and cancellation records are not memory/GC evidence.

The dummy server records request end/payload bytes, response-end supplied body bytes, local response finish/close/error, and cumulative socket byte totals. These socket totals include headers and prior traffic; they are **not per-request delivered-body byte counts**. Local finish does not prove browser delivery or consumption. The unchanged partial-write retry + fdatasync persistence chain remains intact.

The single five-second drain budget starts **after all three policy calls return**. It is never reset. Persistent pre-close ledger/diagnostics capture the outcome before browser cleanup. Cleanup cannot produce a green drain verdict. The unchanged reviewed ledger includes the irreversible deadline-miss latch and separates current physical drain from on-time verification. Initial document navigation is the only browser navigation coverage; general CDP detach/navigation limitations remain.

CLI outcome is explicit: exit **0** only for complete, valid, drained evidence; exit **2** for a complete diagnostic with a missed drain gate; exit **1** for caught semantic/operation problems, incomplete cases, evidence faults, sampled executable survivors or reported cleanup/port failures. Zero-RSS zombies are recorded separately, not executable work. Raw status and body-policy results remain in `result.json`; do not classify exit 2 as an execution crash or as acceptance. Top-level guard/output refusals also exit nonzero. All output creation is exclusive; use a new destination, never cleanup an old run to retry.

No R46 observation exists yet. Its future result cannot identify Measure 37's missing request IDs or establish a picker bug, memory leak, performance win, or goal acceptance.

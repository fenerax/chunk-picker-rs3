import fs from 'node:fs';
import http from 'node:http';
import net from 'node:net';
import assert from 'node:assert/strict';
import { performance } from 'node:perf_hooks';
import { chromium } from '/opt/codex/cua_node/lib/node_modules/playwright-core/index.mjs';
import { createLedger } from './ledger.mjs';
import { validatePhaseConfig } from './phase-config.mjs';
// Refuse before output creation or any server/browser construction. Root stamps once before cloud preparation.
const phase=validatePhaseConfig(JSON.parse(fs.readFileSync(new URL('./phase-config.json',import.meta.url),'utf8')),Date.now());
const prepStartedUtc=phase.startUtc;
for(const path of ['trace.ndjson','browser-stderr.txt','result.json','attempt.lock'])
  if(fs.existsSync(path))throw Error('refuse-existing-phase-output');
fs.closeSync(fs.openSync('attempt.lock','wx',0o600)); // Never removed: this phase permits one attempt.
const caps=Object.freeze({maxEvents:256,maxActive:32,maxRecent:64,maxSessions:4,maxWrites:64,
  maxDocumentsPerSession:4,maxExpectedSsePerTarget:0,traceBytes:131072,traceRows:512,
  samples:220,processes:128,threads:2048,sockets:16,stderrBytes:16384,liveMs:110000,budgetMs:5000});
const start=performance.now(), now=()=>performance.now()-start, sleep=ms=>new Promise(r=>setTimeout(r,ms));
let stage='initial',problem=null,closing=false,browser,browserServer,context,ledger,port,browserPort,timer;
let order=0,bytes=0,queued=0,chain=Promise.resolve(),wireEvents=0,requestCount=0,currentCase='none';
const fd=fs.openSync('trace.ndjson','wx',0o600), samples=[],identities=new Map(),pages=[],targets=new Map(),sockets=new Map(),policies=[];
const report={prepStartedUtc,startedUtc:new Date().toISOString(),caps,attempt:1,
  historicalR42:{sandbox_permissions:'with_additional_permissions',networkEnabled:true,require_escalated:false},
  permissionMode:'not inferred by adapter; caller records permitted cloud scoped-grant receipt'};
function writeAll(buffer,offset=0){return new Promise((resolve,reject)=>fs.write(fd,buffer,offset,buffer.length-offset,null,(error,n)=>{
  if(error)return reject(error);if(!Number.isInteger(n)||n<=0)return reject(Error('zero-write'));
  if(offset+n<buffer.length)writeAll(buffer,offset+n).then(resolve,reject);else resolve();}));}
function persist(row){if(++order>caps.traceRows)throw Error('trace-row-cap');const b=Buffer.from(JSON.stringify({order,...row})+'\n');
  if((bytes+=b.length)>caps.traceBytes||queued>=caps.maxWrites)throw Error('sink-cap');queued++;
  const p=chain.then(()=>writeAll(b)).then(()=>new Promise((resolve,reject)=>fs.fdatasync(fd,e=>e?reject(e):resolve(true))));
  chain=p;return p.finally(()=>queued--);}
const record=(event,fields={})=>persist({kind:'diagnostic',event,at:now(),...fields}).catch(()=>{problem??='sink-failed';});
const ingest=(s,e)=>ledger.ingest({target:s.target,session:s.session,at:now(),...e});
function check(){if(problem)throw Error(problem);if(now()>caps.liveMs-5000)throw Error('live-limit');
  if(ledger?.snapshot().faults.length&&!closing)throw Error('ledger-fault');}
function proc(pid){try{const raw=fs.readFileSync(`/proc/${pid}/stat`,'utf8'),a=raw.slice(raw.lastIndexOf(')')+2).split(' '),s=fs.readFileSync(`/proc/${pid}/status`,'utf8');
  return {pid,ppid:+a[1],startTicks:a[19],state:a[0],rss:+(s.match(/VmRSS:\s+(\d+)/)?.[1]??0)*1024,mask:s.match(/Cpus_allowed_list:\s+(\S+)/)?.[1]};}catch{return null;}}
const guard=proc(process.ppid);report.guard=guard;assert.equal(guard.mask,'0-1');assert.equal(proc(process.pid).mask,'0-1');
function sample(){try{const all=fs.readdirSync('/proc').filter(x=>/^\d+$/.test(x)).map(Number).map(proc).filter(Boolean),owned=new Set([process.pid,guard.pid]);
  let changed=true;while(changed){changed=false;for(const p of all)if(owned.has(p.ppid)&&!owned.has(p.pid)){owned.add(p.pid);changed=true;}}
  const tree=all.filter(p=>owned.has(p.pid));if(tree.length>caps.processes)throw Error('process-cap');let threads=0;
  for(const p of tree){identities.set(p.pid,p.startTicks);for(const tid of fs.readdirSync(`/proc/${p.pid}/task`)){
    if(++threads>caps.threads)throw Error('thread-cap');const s=fs.readFileSync(`/proc/${p.pid}/task/${tid}/status`,'utf8');
    if(s.match(/Cpus_allowed_list:\s+(\S+)/)?.[1]!=='0-1')throw Error('affinity');}}
  const rss=tree.reduce((n,p)=>n+p.rss,0);if(rss>3*1024**3||samples.length>=caps.samples)throw Error('resource-cap');
  samples.push({at:now(),rss,threads,tree});}catch(e){if(e.code!=='ENOENT')problem??='resource-observation-failed';}}
const stderrFd=fs.openSync('browser-stderr.txt','wx',0o600);let stderrBytes=0,stderrLine='';
function stderr(chunk,final=false){stderrLine+=chunk;if(stderrLine.length>4096){problem??='stderr-line-cap';stderrLine=stderrLine.slice(0,4096);}
  const lines=stderrLine.split('\n');stderrLine=final?'':lines.pop();if(final&&stderrLine)lines.push(stderrLine);
  for(const line of lines){const safe=line.replace(/(?:wss?|https?):\/\/\S+/g,'[url]')+'\n';stderrBytes+=Buffer.byteLength(safe);
    if(stderrBytes>caps.stderrBytes){problem??='stderr-cap';return;}fs.writeSync(stderrFd,safe);}}
const responseBody='{"accepted":true}',payload=JSON.stringify({events:[]});
const server=http.createServer((req,res)=>{
  const label=currentCase,q=`q${++requestCount}`,socket=sockets.get(req.socket);
  if(requestCount>6){problem??='unexpected-server-request';res.destroy();return;}
  const route=req.url==='/api/usage'?'/api/usage':req.url==='/__measure37_probe'?'/__measure37_probe':'[other]';
  const base={case:label,serverRequest:q,socket:socket?.alias??'unknown'};
  const totals=()=>({socketBytesRead:req.socket.bytesRead,socketBytesWritten:req.socket.bytesWritten,socketTotals:true});
  void record('server-request',{...base,path:route,method:req.method,...totals()});
  res.setHeader('Content-Type','application/json');res.setHeader('Cache-Control','no-store');
  let received=0;req.on('data',b=>{received+=b.length;if(received>1024){problem??='payload-cap';req.destroy();}});
  req.on('error',()=>{void record('server-request-error',base);problem??='server-request-error';});
  res.on('error',()=>{void record('server-response-error',base);problem??='server-response-error';});
  res.on('finish',()=>void record('server-response-finish',{...base,status:res.statusCode,chunked:res.chunkedEncoding,...totals()}));
  res.on('close',()=>void record('server-response-close',{...base,finished:res.writableFinished,...totals()}));
  req.on('end',()=>{
    void record('server-request-end',{...base,payloadBytes:received,...totals()});
    const body=route==='/api/usage'?responseBody:'<!doctype html><title>R46 dummy</title><link rel="icon" href="data:,">';
    if(route==='/__measure37_probe'){res.setHeader('Content-Type','text/html');res.setHeader('Content-Security-Policy',"default-src 'none'; connect-src 'self'; img-src data:");}
    void record('server-end-supplied',{...base,bodyBytes:Buffer.byteLength(body),status:200});res.end(body);
  });
});
server.on('connection',s=>{if(sockets.size>=caps.sockets){problem??='socket-cap';s.destroy();return;}
  sockets.set(s,{alias:`k${sockets.size+1}`});s.on('error',()=>{problem??='socket-error';});});
try{
  stage='listen';await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  port=server.address().port;const ownedOrigin=`http://127.0.0.1:${port}`;
  ledger=createLedger({ownedOrigin,expectedTargets:3,...caps,sink:line=>persist({kind:'ledger',...JSON.parse(line)})});
  sample();timer=setInterval(sample,500);stage='browser-launch';
  browserServer=await chromium.launchServer({executablePath:'/usr/bin/chromium',headless:true,host:'127.0.0.1',args:['--no-sandbox','--disable-background-networking','--disable-component-update','--disable-sync','--no-first-run','--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1']});
  browserServer.process().stderr?.on('data',b=>stderr(b.toString()));
  browserPort=Number(new URL(browserServer.wsEndpoint()).port);
  browser=await chromium.connect(browserServer.wsEndpoint());report.browserVersion=browser.version();
  browser.on('disconnected',()=>{if(!closing)problem??='native-disconnected';});context=await browser.newContext({serviceWorkers:'block'});
  const root=await browser.newBrowserCDPSession();
  function close(s){if(!s.closed){s.closed=true;ingest(s,{event:'close'});}}
  root.on('Target.targetDestroyed',e=>{const s=targets.get(e.targetId);if(s)close(s);});
  await root.send('Target.setDiscoverTargets',{discover:true});stage='coverage';
  for(let i=0;i<3;i++){const page=await context.newPage(),cdp=await context.newCDPSession(page);pages.push({page,cdp,target:`owned-${i+1}`,session:`epoch-${i+1}`,docs:new Map(),wires:new Map(),closed:false});}
  for(const [i,s]of pages.entries()){
    const info=await s.cdp.send('Target.getTargetInfo');targets.set(info.targetInfo.targetId,s);
    s.page.on('close',()=>close(s));s.page.on('crash',()=>{problem??='native-crash';});ingest(s,{event:'attach'});
    s.cdp.on('Network.requestWillBeSent',e=>{wireEvents++;try{if(!e.loaderId)throw Error('missing-loader');
      if(!s.docs.has(e.loaderId)){if(s.docs.size>=4)throw Error('document-cap');s.docs.set(e.loaderId,`document-${s.docs.size+1}`);}
      const alias=ingest(s,{event:'request',requestId:e.requestId,document:s.docs.get(e.loaderId),url:e.request.url,method:e.request.method,type:e.type,
        redirect:e.redirectResponse!==undefined,redirectStatus:e.redirectResponse?.status});
      if(s.wires.size>=8)throw Error('wire-cap');s.wires.set(e.requestId,{alias});
      if(e.request.method==='POST'){if(s.post)throw Error('duplicate-policy-post');s.post={wire:e.requestId,alias};}
      void record('case-request',{case:e.request.method==='POST'?['ignore','consume','cancel'][i]:`document-${i+1}`,request:alias,target:`t${i+1}`});
    }catch{problem??='request-mapping-failed';}});
    s.cdp.on('Network.responseReceived',e=>{wireEvents++;ingest(s,{event:'response',requestId:e.requestId,status:e.response.status,mime:e.response.mimeType,type:e.type});});
    s.cdp.on('Network.loadingFinished',e=>{wireEvents++;ingest(s,{event:'finished',requestId:e.requestId});});
    s.cdp.on('Network.loadingFailed',e=>{wireEvents++;ingest(s,{event:'failed',requestId:e.requestId,canceled:e.canceled});});
    await s.cdp.send('Network.enable');ingest(s,{event:'enabled'});
  }
  await ledger.flush();report.preNavigation=ledger.snapshot();report.actualTargetCount=targets.size;
  assert.equal(report.preNavigation.counts.requests,0);assert.equal(targets.size,3);
  stage='navigation';for(const [i,s]of pages.entries()){currentCase=`document-${i+1}`;await s.page.goto(`${ownedOrigin}/__measure37_probe`);check();}
  stage='body-policies';
  for(const [i,policy]of ['ignore','consume','cancel'].entries()){
    const s=pages[i];currentCase=policy;await record('policy-start',{case:policy});
    const value=await s.page.evaluate(async({policy,payload})=>{
      const r=await fetch('/api/usage',{method:'POST',keepalive:true,credentials:'same-origin',headers:{'Content-Type':'application/json'},body:payload});
      const result={status:r.status,ok:r.ok,bodyUsedBefore:r.bodyUsed,visibility:document.visibilityState,hidden:document.hidden};
      if(policy==='consume'){const bytes=await r.arrayBuffer();result.bytes=bytes.byteLength;result.readComplete=true;}
      if(policy==='cancel'){await r.body.cancel();result.cancelComplete=true;}
      result.bodyUsed=r.bodyUsed;return result;
    },{policy,payload});
    assert.equal(value.status,200);assert.equal(value.ok,true);assert.equal(value.bodyUsedBefore,false);
    if(policy==='consume'){assert.equal(value.readComplete,true);assert.equal(value.bytes,Buffer.byteLength(responseBody));assert.equal(value.bodyUsed,true);}
    if(policy==='cancel')assert.equal(value.cancelComplete,true);
    if(policy==='ignore')assert.equal(value.bodyUsed,false);
    const entry=s.post;if(!entry)throw Error('body-association-missing');
    if(policy==='consume')ingest(s,{event:'bodyConsumed',requestId:entry.wire,requestAlias:entry.alias});
    const result={case:policy,request:entry.alias,...value};policies.push(result);await record('policy-result',result);check();
  }
  // Freeze after all three calls return; a single start/deadline is never replaced.
  report.drainStartedAt=now();report.deadline=report.drainStartedAt+caps.budgetMs;report.checkpoints=[];stage='drain';
  do{await ledger.flush();await chain;check();const x=ledger.drain({startedAt:report.drainStartedAt,budgetMs:caps.budgetMs,at:now()});
    if(report.checkpoints.length>=64)throw Error('checkpoint-cap');report.checkpoints.push({at:x.at,status:x.status,finite:x.pendingFiniteOrUnknown.map(r=>r.request)});
    report.preClose=x;if(now()<report.deadline)await sleep(Math.min(100,report.deadline-now()+2));
  }while(report.preClose.at<report.deadline);
  await record('pre-close',{status:report.preClose.status,deadline:report.deadline,finite:report.preClose.pendingFiniteOrUnknown.map(r=>r.request)});
  await ledger.flush();await chain;report.persistedBeforeCloseAt=now();
}catch(e){process.exitCode=1;report.failure={stage,code:typeof e.code==='string'?e.code:'operation-failed',name:e.name};
  await record('failure',report.failure);fs.writeSync(2,JSON.stringify({...report.failure,detail:String(e.stack??e).replace(/(?:wss?|https?):\/\/\S+/g,'[url]').slice(0,16384)})+'\n');}
finally{
  closing=true;clearInterval(timer);report.policies=policies;report.wireEvents=wireEvents;report.preCleanup=ledger?.snapshot();
  if(browser)await browser.close().catch(()=>{report.browserCloseFailed=true;});if(browserServer)await browserServer.close().catch(()=>{report.serverCloseFailed=true;});
  for(const s of sockets.keys())s.destroy();if(server.listening)await new Promise(r=>server.close(r));
  await ledger?.flush();report.postClose=ledger?.snapshot();await record('cleanup',{serverListening:server.listening});await chain;
  stderr('',true);fs.fdatasyncSync(stderrFd);fs.closeSync(stderrFd);fs.fdatasyncSync(fd);fs.closeSync(fd);
  report.cleanup=[];for(const [pid,ticks]of identities){if(pid===process.pid||pid===guard.pid)continue;const p=proc(pid);report.cleanup.push({pid,startTicks:ticks,sameProcess:p?.startTicks===ticks,state:p?.state??'gone',rss:p?.rss??0});}
  report.portClosed=port===undefined?'never-bound':await new Promise(r=>{const s=net.connect({host:'127.0.0.1',port});s.once('error',()=>r(true));s.once('connect',()=>{s.destroy();r(false);});});
  report.browserPortClosed=browserPort===undefined?'never-bound':await new Promise(r=>{const s=net.connect({host:'127.0.0.1',port:browserPort});s.once('error',()=>r(true));s.once('connect',()=>{s.destroy();r(false);});});
  report.samples=samples;report.traceRows=order;report.traceBytes=bytes;report.pendingWrites=queued;report.durationMs=now();report.finishedUtc=new Date().toISOString();
  report.problem=problem;
  const invalid=report.failure||problem||report.browserCloseFailed||report.serverCloseFailed||policies.length!==3||
    report.portClosed!==true||report.browserPortClosed!==true||report.cleanup.some(p=>p.sameProcess&&p.state!=='Z')||
    !report.preClose||report.preClose.faults.length||report.pendingWrites!==0;
  report.exitCode=invalid?1:report.preClose.status==='drained'?0:report.preClose.status==='not-drained'?2:1;
  report.status=invalid?'failed-or-incomplete':report.preClose.status==='drained'?'completed-drained':report.preClose.status==='not-drained'?'completed-not-drained':'inconclusive';
  process.exitCode=report.exitCode;
  fs.writeFileSync('result.json',JSON.stringify(report,null,2)+'\n',{mode:0o600,flag:'wx'});console.log(JSON.stringify({failure:report.failure??null,problem,policies,status:report.status,drainStatus:report.preClose?.status,exitCode:report.exitCode,durationMs:report.durationMs,rows:order,bytes,portClosed:report.portClosed}));
}

import assert from 'node:assert/strict';
import { createLedger } from './ledger.mjs';
import { replays } from './replays.mjs';
const ownedOrigin = 'https://owned.invalid';
const make = options => createLedger({ ownedOrigin, ...options });
const base = { target: 'PRIVATE-TARGET', session: 'PRIVATE-SESSION' };
for (const fixture of replays) {
  const rows = []; let at = 0;
  const ledger = make({ expectedTargets: 1, maxEvents: 100,
    sink: line => rows.push(JSON.parse(line)), ...fixture.options });
  const send = e => ledger.ingest({ ...base, at: ++at, ...e });
  send({ event: 'attach' }); send({ event: 'enabled' });
  for (const e of fixture.events) send(e);
  await ledger.flush();
  assert.equal(ledger.drain({ startedAt: at, budgetMs: 10, at: at + 10 }).status, fixture.want, fixture.name);
  if (fixture.fault) assert(ledger.snapshot().faults.includes(fixture.fault), fixture.name + ': specific fault');
  const exported = JSON.stringify([rows, ledger.snapshot()]);
  for (const secret of ['PRIVATE-TARGET', 'PRIVATE-SESSION', 'must-not-export', 'SECRET-ERROR', 'external.invalid', 'EXTERNAL-SECRET', 'owned.invalid'])
    assert(!exported.includes(secret), fixture.name + ': privacy');
  if (fixture.name.startsWith('duplicate terminal')) assert.equal(ledger.snapshot().counts.finished, 2);
}
// Application body-read may occur after network completion, without merging a reused wire ID.
const lines = []; const l = make({ expectedTargets: 1, maxEvents: 30, sink: s => lines.push(s) });
let time = 0; const send = e => l.ingest({ ...base, at: ++time, ...e });
send({ event: 'attach' }); send({ event: 'enabled' });
const alias = send({ event: 'request', requestId: 'WIRE-SECRET', document: 'DOC-SECRET',
  method: 'GET', url: '/join/JOIN-SECRET?receipt=RECEIPT-SECRET', type: 'Fetch' });
send({ event: 'response', requestId: 'WIRE-SECRET', status: 200, mime: 'application/json' });
send({ event: 'finished', requestId: 'WIRE-SECRET' });
send({ event: 'bodyConsumed', requestId: 'WIRE-SECRET', requestAlias: alias });
assert.equal(l.snapshot().counts.bodyConsumed, 1);
for (const secret of ['WIRE-SECRET', 'DOC-SECRET', 'JOIN-SECRET', 'RECEIPT-SECRET']) assert(!lines.join('').includes(secret));
assert.equal(l.drain({ startedAt: time, budgetMs: 20, at: time }).status, 'drained');
assert.throws(() => l.drain({ startedAt: time, budgetMs: 21, at: time }));
// Four targets must be ready; three quiet pages cannot establish four-page drain.
const four = make({ expectedTargets: 4, maxEvents: 20, sink() {} });
for (let i = 0; i < 3; i++) {
  four.ingest({ event: 'attach', target: `p${i}`, session: 's', at: i * 2 });
  four.ingest({ event: 'enabled', target: `p${i}`, session: 's', at: i * 2 + 1 });
}
assert.equal(four.drain({ startedAt: 6, budgetMs: 0, at: 6 }).status, 'inconclusive');
const broken = make({ expectedTargets: 1, maxEvents: 10, sink() { throw Error('SECRET'); } });
broken.ingest({ ...base, event: 'attach', at: 0 });
assert(broken.snapshot().faults.includes('sink-failed'));
let release;
const blocked = make({ expectedTargets: 1, maxEvents: 10, maxWrites: 1,
  sink: () => new Promise(resolve => { release = resolve; }) });
blocked.ingest({ ...base, event: 'attach', at: 0 });
blocked.ingest({ ...base, event: 'enabled', at: 1 });
release(); await blocked.flush();
assert(blocked.snapshot().faults.includes('sink-backpressure'));
assert.equal(blocked.snapshot().counts.dropped, 1);
const excess = make({ expectedTargets: 1, maxEvents: 20, sink() {} });
let tick = 0; const put = e => excess.ingest({ ...base, at: ++tick, ...e });
put({ event: 'attach' }); put({ event: 'enabled' });
for (const id of ['s1', 's2']) {
  put({ event: 'request', requestId: id, document: 'd', url: '/api/events', method: 'GET', type: 'EventSource' });
  put({ event: 'response', requestId: id, mime: 'text/event-stream', status: 200, type: 'EventSource' });
}
assert.equal(excess.drain({ startedAt: tick, budgetMs: 0, at: tick }).status, 'not-drained');
// Two sessions on A cannot substitute for an unenabled B target.
const coverage = make({ expectedTargets: 2, maxEvents: 20, sink() {} });
let t = 0;
for (const [target, session, enabled] of [['A', 'one', true], ['A', 'two', true], ['B', 'one', false]]) {
  coverage.ingest({ event: 'attach', target, session, at: ++t });
  if (enabled) coverage.ingest({ event: 'enabled', target, session, at: ++t });
}
assert.equal(coverage.snapshot().sessionsReady, 2);
assert.equal(coverage.snapshot().readyTargets, 1);
assert.equal(coverage.drain({ startedAt: t, budgetMs: 0, at: t }).status, 'inconclusive');
// Late resources from the earlier document keep that document's local identity.
const docs = []; const stable = make({ expectedTargets: 1, maxEvents: 20, sink: s => docs.push(JSON.parse(s)) });
let d = 0; const record = e => stable.ingest({ ...base, at: ++d, ...e });
record({ event: 'attach' }); record({ event: 'enabled' });
for (const [requestId, document] of [['a', 'old'], ['b', 'new'], ['c', 'old']])
  record({ event: 'request', requestId, document, url: '/api/state', method: 'GET', type: 'Fetch' });
const docRows = docs.filter(x => x.event === 'request');
assert.equal(docRows[0].document, docRows[2].document); assert.notEqual(docRows[0].document, docRows[1].document);
for (const sink of [() => false, async () => false]) {
  const refusing = make({ expectedTargets: 1, maxEvents: 10, sink });
  refusing.ingest({ ...base, event: 'attach', at: 0 }); await refusing.flush();
  assert(refusing.snapshot().faults.includes('sink-backpressure'));
}
// A terminal event backdated before a checkpoint cannot repair pending work.
const barrier = make({ expectedTargets: 1, maxEvents: 10, sink() {} });
barrier.ingest({ ...base, event: 'attach', at: 0 }); barrier.ingest({ ...base, event: 'enabled', at: 1 });
barrier.ingest({ ...base, event: 'request', at: 2, requestId: 'q', document: 'd', url: '/api/state', type: 'Fetch', method: 'GET' });
barrier.ingest({ ...base, event: 'response', at: 3, requestId: 'q', status: 200, mime: 'application/json' });
assert.equal(barrier.drain({ startedAt: 4, budgetMs: 96, at: 100 }).status, 'not-drained');
barrier.ingest({ ...base, event: 'finished', at: 99, requestId: 'q' });
assert.equal(barrier.snapshot().pending.length, 1);
assert.equal(barrier.drain({ startedAt: 4, budgetMs: 96, at: 101 }).status, 'inconclusive');
assert(barrier.snapshot().faults.includes('invalid-time-order'));
const priorPass = make({ expectedTargets: 1, maxEvents: 10, sink() {} });
priorPass.ingest({ ...base, event: 'attach', at: 0 }); priorPass.ingest({ ...base, event: 'enabled', at: 1 });
assert.equal(priorPass.drain({ startedAt: 2, budgetMs: 98, at: 100 }).status, 'drained');
priorPass.ingest({ ...base, event: 'request', at: 99, requestId: 'late', document: 'd', url: '/api/state', method: 'GET' });
assert.equal(priorPass.snapshot().pending.length, 0);
assert.equal(priorPass.drain({ startedAt: 2, budgetMs: 98, at: 101 }).status, 'inconclusive');
// A later physical drain cannot turn a missed frozen deadline into an on-time pass.
const missed = make({ expectedTargets: 1, maxEvents: 20, sink() {} });
missed.ingest({ ...base, event: 'attach', at: 0 }); missed.ingest({ ...base, event: 'enabled', at: 1 });
missed.ingest({ ...base, event: 'request', at: 2, requestId: 'm', document: 'd', url: '/api/state', method: 'GET', type: 'Fetch' });
missed.ingest({ ...base, event: 'response', at: 3, requestId: 'm', status: 200, mime: 'application/json' });
const checkpoint = at => missed.drain({ startedAt: 4, budgetMs: 96, at });
assert.equal(checkpoint(50).status, 'waiting');
assert.equal(checkpoint(100).status, 'not-drained');
missed.ingest({ ...base, event: 'finished', requestId: 'm', at: 101 });
const later = checkpoint(102);
assert.equal(later.status, 'not-drained'); assert.equal(later.deadlineMissed, true);
assert.equal(later.currentlyDrained, true); assert.equal(later.onTimeVerifiedAt, null);
const lateEmpty = make({ expectedTargets: 1, maxEvents: 10, sink() {} });
lateEmpty.ingest({ ...base, event: 'attach', at: 0 }); lateEmpty.ingest({ ...base, event: 'enabled', at: 1 });
const late = lateEmpty.drain({ startedAt: 2, budgetMs: 98, at: 101 });
assert.equal(late.status, 'not-drained'); assert.equal(late.currentlyDrained, true);
assert.equal(late.onTimeVerifiedAt, null); assert.equal(late.deadlineMissed, true);
// Earlier quiet evidence cannot cover new work whose eventual drain is observed late.
const newWork = make({ expectedTargets: 1, maxEvents: 20, sink() {} });
newWork.ingest({ ...base, event: 'attach', at: 0 }); newWork.ingest({ ...base, event: 'enabled', at: 1 });
assert.equal(newWork.drain({ startedAt: 2, budgetMs: 98, at: 50 }).status, 'drained');
newWork.ingest({ ...base, event: 'request', at: 60, requestId: 'new', document: 'd', url: '/api/state', method: 'GET', type: 'Fetch' });
newWork.ingest({ ...base, event: 'response', at: 61, requestId: 'new', status: 200, mime: 'application/json' });
newWork.ingest({ ...base, event: 'finished', at: 101, requestId: 'new' });
assert.equal(newWork.drain({ startedAt: 2, budgetMs: 98, at: 102 }).status, 'not-drained');
console.log(`Passed ${replays.length} semantic replays plus privacy, body, budget, four-target and sink controls.`);

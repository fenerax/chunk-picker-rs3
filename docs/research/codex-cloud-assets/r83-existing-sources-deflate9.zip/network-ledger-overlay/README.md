# Explicit overlay-stream ledger candidate

Test-only, separate candidate. `../network-ledger/ledger.mjs` remains unchanged at SHA256 `5bad0bff91320fb3ebba510de124bdb98e611d8c1cda4de85e8fb9c9e2fd60c3`. No app code is imported and no browser, service or timer is started. Run only the authored pure controls with `node overlay-selftest.mjs`.

## Closed optional stream contract

Omitting `expectedStreamContracts` preserves the original defaults, sanitized rows and verdicts. The copied `replays.mjs` and `selftest.mjs` are byte-identical to the original controls. All29 semantic replays also receive deep output/snapshot/verdict comparison against the original ledger.

Supplying `expectedStreamContracts` selects a separate strict mode. Before measurement, freeze the actual opaque target aliases, exact CDP session epochs, page roles and stream capacities. The adapter must create targets/sessions and resolve these aliases before constructing this ledger, installing/enabling its listeners and navigating. There is no wildcard, automatic role inference, late registration or session rebinding. Exactly one stream contract is allowed per unique actual page target; a second declared session on that target is rejected, even with the same role. Contracts must cover every distinct `expectedTargets` target and fit `maxSessions`. Missing a declared page leaves coverage inconclusive. A replacement session is outside this frozen scope; dynamic reattachment is not implemented.

Every contract must have exactly these fields, with primitive values:

```js
{
  target: overlayTargetAlias, session: overlaySessionAlias,
  role: 'overlay', targetType: 'page',
  path: '/overlay/events', method: 'GET',
  requestType: 'Fetch', responseType: 'Fetch', capacity: 1
}
```

The only other reviewed row is `role:'player'`, `targetType:'page'`, `path:'/api/events'`, `method:'GET'`, `requestType:'EventSource'`, `responseType:'EventSource'`. Both identities must be nonempty primitive strings, at most256 characters. Capacity is a positive safe integer no larger than the frozen `maxExpectedSsePerTarget`. Each contract is defensively copied and internally frozen; mutation of caller objects/arrays cannot broaden it. Contract values and caller identities are never emitted.

The corresponding `attach` event must include matching primitive `role` and `targetType` values as well as its exact target/session aliases. Missing/unexpected scope or wrong role/type faults coverage permanently. These are adapter declarations, not independently observed browser evidence.

To exempt an open stream, request and response must match the contract's exact CDP type pair. Its request must be a primitive URL string resolving to the frozen owned origin and reviewed pathname, with primitive GET method. Response status must be an integer2xx and MIME must be a primitive `text/event-stream` string; case, outer whitespace and MIME parameters use the original normalization. Missing/boxed/coerced types/statuses, XHR, external same-path streams, POST and other Fetch endpoints get no exemption. Query strings are never exported. Native EventSource is never synthesized from Fetch evidence.

Only explicit contracts govern streams in strict mode; legacy `expectedSseRoutes` does not broaden or filter them. All original option validation still applies. The original `maxExpectedSsePerTarget` cap remains in force, and each contract's capacity is enforced independently; strict mode cannot declare alternative sessions on one target. Overcapacity remains blocking until terminal transport evidence arrives. Wrong types/MIME/routes remain finite-or-unknown rather than being declared complete. Request close/cancel/failure, sink persistence/backpressure, body association, bounded state, coverage, checkpoint barriers and irreversible drain deadlines retain their original meaning. A completed transport request is not successful product work.

Use the original persistent sink adapter contract and externally frozen capacities/deadline. This candidate provides no file sink, body-read adapter, product oracle, memory budget, implicit timeout or soak integration. New sanitized `streamContract:cN` tags identify declared contracts without exporting caller IDs.

## Source evidence and unverified browser hypothesis

Pinned public source: `9b225296b045d6b395f79fde290d4321e36aeeae`, `app/web/overlay-client.mjs`, Git blob `1bc8b61fefe895872bb0ffd554baf9014197e2cd`. Read through anonymous/read-only GitHub API content retrieval. [Lines132–143](https://github.com/fenerax/chunk-picker-rs3/blob/9b225296b045d6b395f79fde290d4321e36aeeae/app/web/overlay-client.mjs#L132-L143) use streaming `fetch('/overlay/events?...')` and `response.body.getReader()`, with no explicit method (Fetch GET default). This source supports the route/API distinction from native EventSource; it does not establish observed CDP request/response resource types.

**Fetch/Fetch is a frozen hypothesis pending actual-browser conformance**, not verified runtime evidence. If either CDP type differs, this contract must fail closed; preserve that outcome and review the actual transport before any contract revision. No live CDP capture, app/browser/server run, benchmark, integration or final-session acceptance has occurred.

## Verification receipt

Local pure controls ran with Node v24.20.0. Passed unchanged29 semantic replays and all their original privacy/body/budget/target/sink controls, plus106 additional controls:29 default differential replays and77 strict overlay/configuration/invariant controls. Positive cases cover native player EventSource, owned overlay Fetch, MIME parameters, and two-player/one-overlay coverage. Negative cases cover scope/role/session/type/method/origin/route/MIME/status, missing headers, boxed values, capacities, malformed/overlapping contracts, caller mutation, sink refusal, lifecycle and irreversible deadline behavior. The coverage regression specifically rejects two sessions declared on one target and verifies that an entirely unobserved declared page remains inconclusive despite the observed player's valid open stream.

Two test-helper mistakes in early development (moving frozen drain bounds and retaining the mutable caller-array reference in the helper's own send scope) were corrected before the passing run. They were test-only failures, not product defects. Original collector and semantic-control source hashes were rechecked afterward. `hashes.json` records exact candidate file hashes; `candidate.patch` adds a separate candidate directory and does not modify the original collector.

Independent review found a false-pass in the initial candidate: it allowed two declared contract sessions on one target while inherited coverage counted distinct targets only, so one never-observed declared session could be ignored. The current one-session-per-page adapter does not need that flexibility. Construction now rejects every duplicate target, rather than adding dynamic-session coverage rules. `review-initial/` preserves the complete original candidate, patch, manifest, README and receipts. Its passing controls did not cover this defect and are not acceptance evidence for the corrected contract.

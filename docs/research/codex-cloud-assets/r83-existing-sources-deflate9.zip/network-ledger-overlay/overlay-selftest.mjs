// Pure authored transport controls. Imports no app, browser, profiler or service.
import assert from 'node:assert/strict';
import './selftest.mjs'; // Unchanged 29 semantic replays and all original extra controls.
import { createLedger } from './ledger.mjs';
import { createLedger as originalLedger } from '../network-ledger/ledger.mjs';
import { replays } from './replays.mjs';
const origin = 'https://owned.invalid';
const overlay = more => ({ target: 'PRIVATE-OVERLAY', session: 'PRIVATE-OVERLAY-SESSION', role: 'overlay', targetType: 'page',
  path: '/overlay/events', method: 'GET', requestType: 'Fetch', responseType: 'Fetch', capacity: 1, ...more });
const player = more => ({ target: 'PRIVATE-PLAYER', session: 'PRIVATE-PLAYER-SESSION', role: 'player', targetType: 'page',
  path: '/api/events', method: 'GET', requestType: 'EventSource', responseType: 'EventSource', capacity: 1, ...more });
let checks = 0;
function test(name, work) { work(); checks++; }
function setup({ contracts = [overlay()], attach = {}, options = {}, sink } = {}) {
  const lines = [], expectedTargets = new Set(contracts.map(c => c.target)).size;
  const ledger = createLedger({ sink: sink ?? (s => lines.push(JSON.parse(s))), ownedOrigin: origin,
    expectedTargets, maxEvents: 150, expectedStreamContracts: contracts, ...options });
  let time = 0, drainStarted;
  const defaultScope = { target: contracts[0].target, session: contracts[0].session };
  const send = e => ledger.ingest({ ...defaultScope, at: ++time, ...e });
  for (const c of contracts) {
    send({ event: 'attach', target: c.target, session: c.session, role: c.role, targetType: c.targetType, ...attach });
    send({ event: 'enabled', target: c.target, session: c.session, ...attach });
  }
  const request = (more = {}) => send({ event: 'request', requestId: 'PRIVATE-WIRE', document: 'PRIVATE-DOC',
    method: 'GET', url: '/overlay/events?key=PRIVATE-QUERY', type: 'Fetch', ...more });
  const response = (more = {}) => send({ event: 'response', requestId: 'PRIVATE-WIRE', status: 200,
    mime: 'text/event-stream', type: 'Fetch', ...more });
  const drain = () => ledger.drain({ startedAt: drainStarted ??= time, budgetMs: 0, at: time });
  return { ledger, lines, send, request, response, drain };
}
function expect(name, request = {}, response = {}, status = 'not-drained', config) {
  test(name, () => { const h = setup(config); h.request(request); h.response(response); assert.equal(h.drain().status, status, name); });
}
// Default output/verdict equivalence is stronger than merely rerunning success assertions.
for (const replay of replays) test('default differential: ' + replay.name, () => {
  const run = factory => {
    const lines = [], l = factory({ ownedOrigin: origin, expectedTargets: 1, maxEvents: 100,
      sink: s => lines.push(JSON.parse(s)), ...replay.options });
    let at = 0; const send = e => l.ingest({ target: 'PRIVATE-TARGET', session: 'PRIVATE-SESSION', at: ++at, ...e });
    send({ event: 'attach' }); send({ event: 'enabled' }); for (const e of replay.events) send(e);
    return { lines, snapshot: l.snapshot(), drain: l.drain({ startedAt: at, budgetMs: 10, at: at + 10 }) };
  };
  assert.deepEqual(run(createLedger), run(originalLedger), replay.name);
});
expect('explicit owned overlay Fetch stream', {}, {}, 'drained');
expect('integer 299 and MIME parameters', {}, { status: 299, mime: ' Text/Event-Stream; charset=utf-8 ' }, 'drained');
expect('reviewed absolute owned URL', { url: origin + '/overlay/events?secret=PRIVATE-QUERY' }, {}, 'drained');
expect('external same path', { url: 'https://external.invalid/overlay/events?secret=PRIVATE-QUERY' });
expect('unexpected arbitrary Fetch SSE', { url: '/api/state' });
expect('unexpected suffix route', { url: '/overlay/events/extra' });
expect('unexpected native route for overlay', { url: '/api/events' });
expect('POST SSE', { method: 'POST' });
expect('lowercase method is not coerced', { method: 'get' });
expect('boxed method is not coerced', { method: new String('GET') });
expect('URL object is not coerced', { url: new URL(origin + '/overlay/events') });
expect('URL coercion callback is never invoked', { url: { toString() { throw Error('must not coerce'); } } });
for (const [requestType, responseType] of [['EventSource', 'EventSource'], ['EventSource', 'Fetch'], ['Fetch', 'EventSource'],
  ['XHR', 'Fetch'], ['Fetch', 'XHR'], [undefined, 'Fetch'], ['Fetch', undefined], ['UnrecognizedType', 'Fetch'], ['Fetch', new String('Fetch')]])
  expect(`wrong/missing type pair ${String(requestType)}/${String(responseType)}`, { type: requestType }, { type: responseType });
for (const status of [199, 300, 503]) expect('non-2xx ' + status, {}, { status });
for (const status of ['200', true, new Number(200), 200.5, NaN, Infinity, 700])
  expect('invalid status is not coerced ' + String(status), {}, { status }, 'inconclusive');
for (const mime of [undefined, 'application/json', 'text/event-streamx', new String('text/event-stream')])
  expect('wrong/untyped MIME ' + String(mime), {}, { mime });
test('headers missing cannot exempt Fetch', () => { const h = setup(); h.request(); assert.equal(h.drain().status, 'not-drained'); });
test('player native EventSource unchanged under explicit scope', () => {
  const h = setup({ contracts: [player()] }); h.request({ url: '/api/events', type: 'EventSource' }); h.response({ type: 'EventSource' });
  assert.equal(h.drain().status, 'drained');
});
expect('player cannot borrow an overlay stream contract', {}, {}, 'not-drained', { contracts: [player()] });
expect('player cannot borrow overlay with EventSource either', { type: 'EventSource' }, { type: 'EventSource' }, 'not-drained', { contracts: [player()] });
expect('unknown target cannot borrow contract', { target: 'PRIVATE-UNKNOWN' }, { target: 'PRIVATE-UNKNOWN' }, 'inconclusive');
expect('unknown session cannot borrow contract', { session: 'PRIVATE-UNKNOWN' }, { session: 'PRIVATE-UNKNOWN' }, 'inconclusive');
for (const attach of [{ role: 'player' }, { targetType: 'worker' }, { role: undefined }, { targetType: undefined }, { session: 'PRIVATE-OTHER' }])
  expect('attach scope mismatch ' + JSON.stringify(attach), {}, {}, 'inconclusive', { attach });
test('two players and one overlay require all frozen targets and preserve privacy', () => {
  const h = setup({ contracts: [player(), player({ target: 'PRIVATE-PLAYER2', session: 'PRIVATE-PLAYER2-SESSION' }), overlay()] });
  for (const c of [player(), player({ target: 'PRIVATE-PLAYER2', session: 'PRIVATE-PLAYER2-SESSION' }), overlay()]) {
    const scope = { target: c.target, session: c.session };
    h.request({ ...scope, type: c.requestType, url: c.path + '?key=PRIVATE-QUERY' }); h.response({ ...scope, type: c.responseType });
  }
  const d = h.drain(); assert.equal(d.status, 'drained'); assert.equal(d.pending.length, 3);
  const exported = JSON.stringify([h.lines, d]);
  for (const secret of ['PRIVATE-', 'owned.invalid', 'text/event-stream?']) assert(!exported.includes(secret));
});
test('two simultaneous streams exceed per-contract capacity', () => {
  const h = setup({ options: { maxExpectedSsePerTarget: 2 } }); h.request(); h.response();
  h.request({ requestId: 'PRIVATE-SECOND' }); h.response({ requestId: 'PRIVATE-SECOND' });
  const d = h.drain(); assert.equal(d.status, 'not-drained'); assert.equal(d.blocking.length, 1);
});
test('second declared session on the same page cannot hide missing coverage', () => {
  assert.throws(() => setup({ contracts: [overlay(), overlay({ session: 'PRIVATE-SECOND-SESSION' })] }),
    /one stream contract per target required/);
});
test('a declared but never observed page remains inconclusive', () => {
  const contracts = [player(), overlay()];
  const l = createLedger({ ownedOrigin: origin, sink() {}, expectedTargets: 2, maxEvents: 20, expectedStreamContracts: contracts });
  const scope = { target: player().target, session: player().session };
  l.ingest({ ...scope, event: 'attach', role: 'player', targetType: 'page', at: 0 });
  l.ingest({ ...scope, event: 'enabled', at: 1 });
  l.ingest({ ...scope, event: 'request', at: 2, requestId: 'wire', document: 'doc', url: '/api/events', method: 'GET', type: 'EventSource' });
  l.ingest({ ...scope, event: 'response', at: 3, requestId: 'wire', status: 200, mime: 'text/event-stream', type: 'EventSource' });
  const d = l.drain({ startedAt: 4, budgetMs: 0, at: 4 });
  assert.equal(d.status, 'inconclusive'); assert.equal(d.targets, 1); assert.equal(d.readyTargets, 1);
  assert.deepEqual(d.faults, []); assert.equal(d.blocking.length, 0);
});
test('finite nonstream response still completes normally', () => {
  const h = setup(); h.request({ url: '/api/state' }); h.response({ mime: 'application/json' }); h.send({ event: 'finished', requestId: 'PRIVATE-WIRE' });
  assert.equal(h.drain().status, 'drained');
});
test('failed stream is terminal evidence but close still destroys coverage', () => {
  const h = setup(); h.request(); h.response(); h.send({ event: 'failed', requestId: 'PRIVATE-WIRE', canceled: true, errorText: 'PRIVATE-ERROR' });
  assert.equal(h.drain().status, 'drained'); h.send({ event: 'close' }); assert.equal(h.drain().status, 'inconclusive');
});
test('mutating caller config cannot expand route/type/scope/capacity', () => {
  const c = overlay(), contracts = [c], h = setup({ contracts, options: { maxExpectedSsePerTarget: 2 } });
  Object.assign(c, { target: 'PRIVATE-OTHER', session: 'PRIVATE-OTHER', role: 'player', targetType: 'worker', path: '/api/state',
    method: 'POST', requestType: 'XHR', responseType: 'XHR', capacity: 99 }); contracts.length = 0;
  h.request(); h.response(); assert.equal(h.drain().status, 'drained');
  h.request({ requestId: 'PRIVATE-MUTATED', method: 'POST', type: 'XHR', url: '/api/state' });
  h.response({ requestId: 'PRIVATE-MUTATED', type: 'XHR' });
  assert.equal(h.ledger.snapshot().pending.find(r => r.method === 'POST').expectedSse, false);
  h.send({ event: 'finished', requestId: 'PRIVATE-MUTATED' });
  h.request({ requestId: 'PRIVATE-SECOND' }); h.response({ requestId: 'PRIVATE-SECOND' });
  const d = h.drain(); assert.equal(d.status, 'not-drained'); assert.equal(d.blocking.length, 1);
});
const invalidContracts = [null, {}, [null], [overlay({ arbitrary: true })], [overlay({ target: '' })], [overlay({ target: new String('x') })],
  [overlay({ session: 1 })], [overlay({ targetType: 'worker' })], [overlay({ method: 'POST' })], [overlay({ role: 'other' })],
  [overlay({ path: '/api/state' })], [overlay({ requestType: 'EventSource' })], [overlay({ responseType: 'EventSource' })],
  [overlay({ capacity: '1' })], [overlay({ capacity: 0 })], [overlay({ capacity: 1.5 })], [overlay({ capacity: 2 })],
  [overlay(), overlay()], [overlay(), player({ target: overlay().target, session: 'PRIVATE-OTHER' })]];
for (const [index, contracts] of invalidContracts.entries()) test('invalid contract ' + index, () => {
  assert.throws(() => createLedger({ ownedOrigin: origin, sink() {}, expectedTargets: 1, maxEvents: 20, expectedStreamContracts: contracts }));
});
test('all target aliases must be frozen', () => assert.throws(() => createLedger({ ownedOrigin: origin, sink() {},
  expectedTargets: 2, maxEvents: 20, expectedStreamContracts: [overlay()] })));
test('contract count respects session bound', () => assert.throws(() => createLedger({ ownedOrigin: origin, sink() {},
  expectedTargets: 2, maxSessions: 1, maxEvents: 20, expectedStreamContracts: [overlay(), player()] })));
test('contract array is not the legacy default when empty', () => assert.throws(() => createLedger({ ownedOrigin: origin, sink() {},
  expectedTargets: 1, maxEvents: 20, expectedStreamContracts: [] })));
test('explicit stream does not bypass a sink fault', () => {
  const h = setup({ sink() { return false; } }); h.request(); h.response(); assert.equal(h.drain().status, 'inconclusive');
});
test('late correct headers cannot repair missed frozen deadline', () => {
  const h = setup(); h.request(); const first = h.ledger.drain({ startedAt: 3, budgetMs: 0, at: 3 });
  assert.equal(first.status, 'not-drained'); h.response();
  const later = h.ledger.drain({ startedAt: 3, budgetMs: 0, at: 4 });
  assert.equal(later.currentlyDrained, true); assert.equal(later.status, 'not-drained'); assert.equal(later.deadlineMissed, true);
});
console.log(`Passed ${checks} overlay/default-differential pure controls, plus unchanged original controls. No CDP/browser conformance tested.`);

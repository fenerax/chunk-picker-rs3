# Independent corrected-ledger review

Scope: static whole-file review of ledger.mjs, README.md, replays.mjs, selftest.mjs and review-fix-receipt.md. No tests, browser/server/product workload, benchmark, cloud dispatch or GitHub mutation performed. Only this review receipt was written.

## Reviewed hashes

| File | Independently read SHA-256 |
| --- | --- |
| ledger.mjs | 9cc69818c24bc87eef150e672f9e5a4caeb5910019ca1bd40c0a92d6e7a3fdd3 |
| README.md | 32d9b86ad21c24759d9482afabdc1d924f2ae9326f68e7995d04cf8a3cdc5609 |
| replays.mjs | 5e71fbdd3b1eb36205a5fb942841d2710ed3d5791680f41bfbd68b46db72013e |
| selftest.mjs | 80aa49632ed7f7638a84daa23bf8d5ddf2fe32297f64047d0ffcb6fdfaa3208d |

All four match the author's fix receipt. The reported 26 passing replays are author evidence, not rerun by this reviewer.

## Seven fixes verified in source

Distinct ready-target coverage replaces aggregate session readiness. SSE requires owned origin, GET and integer successful status, with a copied route contract. Stable bounded per-session document aliases preserve old/new/old requests. Successful finish without headers faults; failed/canceled terminals remain transport completion, not action success. Synchronous/resolved false sink returns fault. Only integer 3xx evidence closes redirect hops; malformed evidence retains ambiguity. Drain checkpoints advance the monotonic barrier. Corresponding negative controls are present, alongside overflow/secret/body/duplicate/close checks.

## Remaining false-pass path

**Do not call this revision clean yet.** The response branch still falls back from missing/unrecognized response type to the request type, then derives SSE eligibility without requiring consistency with the original request type:

```js
const type = TYPES.has(e.type) ? e.type : r.type;
r.sse = eventStream && type === 'EventSource' && Number.isInteger(e.status) && e.status >= 200 && e.status < 300;
```

After normal attach/enabled, either of these source-inspected sequences can leave an expected stream and return drained without a terminal:

1. Owned GET /api/events request typed Fetch; response typed EventSource, status 200, MIME text/event-stream. Snapshot still exports initiation type Fetch but exempts it as expected SSE.
2. Owned GET /api/events request typed EventSource; response has missing or invalid type, status 200, MIME text/event-stream. Fallback manufactures the required response classification instead of retaining missing evidence.

This conflicts with the documented supplied response type and conservative MIME/type contradiction rule. Require explicit compatible EventSource request and response evidence for exemption, or record an evidence fault. Add negative replays for contradictory types in both directions and missing/invalid response type. The existing wrong-response-type case covers only EventSource request followed by Fetch response. Both root and author were notified.

No other new false-pass path was identified in the bounded static review. This is not integrated-soak readiness or acceptance; the actual CDP adapter, durable sink, document mapping, event coverage and final drain checkpoint remain unverified. A controlled dummy-app CDP smoke can assess those boundaries only after the remaining classification guard is resolved and pinned.

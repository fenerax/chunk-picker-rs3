# Network ledger independent-review fix receipt

This receipt records root and `/root/backend_experiments` static findings and the test-only response. No product source, provider, browser, server, benchmark, cloud job or GitHub action was run. The collector is not integrated into a soak, and independent re-review remains required. The original Measure 37 drain evidence remains unresolved.

## Initial prototype preserved

`review-initial/` contains byte-for-byte copies before these fixes. Its initial passing authored controls did not exercise the false-acceptance cases below and do not establish readiness. These files are historical review evidence, not the current implementation.

| File in review-initial/ | SHA-256 |
|---|---|
| ledger.mjs | f94f71fdcff55508160a0fbc74245f7bcf7c8fd416df2c82a04fde8848dc01af |
| README.md | f3bae9f9b2dcc471bcb0a6cd8ea3778e405912d897bcb15b219d299a324364b1 |
| replays.mjs | 9ebad571daf930718cd2928a620f6c3a922fce1b9eca4285d3f84cf3674f7bec |
| selftest.mjs | f6d16732e7e1c19648b7cf1463539f11708937446dd17dcf903501cac9115f53 |

## Review findings and fixes

1. Aggregate enabled-session counts could falsely cover a different unenabled target. Readiness now counts distinct targets with an enabled open session. The exact A/session1 + A/session2 enabled, B/session1 unenabled scenario is a negative control.
2. Path-only SSE classification could exempt a foreign-origin stream. The constructor now requires an exact frozen owned HTTP(S) origin, retained only in memory. Expected SSE also requires GET, observed EventSource type/MIME, an integer 2xx status, a copied allowlisted route contract and capacity. Foreign-origin, POST, string-status and wrong-type controls block exemption; exported records contain only safe route/type values and an owned boolean.
3. Last-seen-document aliasing split an older document's late resource into a new identity. A bounded per-session map now preserves old/new/old document aliases, with an explicit document-cap fault.
4. Successful loadingFinished could pass without response evidence. It now faults as incomplete; no implicit protocol/cache exception is enabled. Valid positive controls include preceding headers. loadingFailed may still legitimately occur before a response and is not product success.
5. A sink returning false was ignored. Synchronous and asynchronously resolved false now mark permanent backpressure faults. A persistent sink adapter must acknowledge its own durability contract; a bare writable buffer result is not a durability guarantee.
6. A missing, coerced or non-3xx redirect status could close an old hop. Only integer 3xx evidence closes it; malformed redirect evidence faults and preserves the ambiguous earlier active entry. Replays cover all three malformed cases and a valid redirect.
7. A drain checkpoint did not advance the monotonic event barrier. It now does. A later backdated terminal cannot repair outstanding work, and a backdated request cannot silently contradict a previously quiet checkpoint; subsequent decisions become inconclusive. Replay controls cover both directions.

Capacity, duplicate/orphan/cancellation handling and export-secret controls remain. Raw event counters remain separate from derived request sets. Ambiguous nonredirect wire-ID reuse and closed target/session coverage remain inconclusive rather than being cleared to pass. Final adapter documentation retains the unknown worker-transport qualification and requires an explicit final mode plus process/diagnostic receipt.

## First-fix verification and reviewed hashes

`node --check` passed separately for ledger.mjs, replays.mjs and selftest.mjs. The isolated pure selftest completed with:

```text
Passed 26 semantic replays plus privacy, body, budget, four-target and sink controls.
```

Additional controls include distinct-target readiness, stable document attribution, false sink responses, excessive SSE capacity, persisted-write backpressure, separate application-body consumption, frozen drain budgets and both checkpoint-barrier directions. These are deterministic event replays, not product tests or runtime performance measurements.

| First-fix file reviewed by backend (superseded below) | SHA-256 |
|---|---|
| ledger.mjs (173 lines) | 9cc69818c24bc87eef150e672f9e5a4caeb5910019ca1bd40c0a92d6e7a3fdd3 |
| README.md | 32d9b86ad21c24759d9482afabdc1d924f2ae9326f68e7995d04cf8a3cdc5609 |
| replays.mjs | 5e71fbdd3b1eb36205a5fb942841d2710ed3d5791680f41bfbd68b46db72013e |
| selftest.mjs | 80aa49632ed7f7638a84daa23bf8d5ddf2fe32297f64047d0ffcb6fdfaa3208d |

## Final type-consistency correction

Independent backend re-review confirmed the seven fixes, then identified a remaining exemption gap: a Fetch initiation plus EventSource response could be exempted, and missing/invalid response types could borrow the request type. The SSE guard now requires explicit EventSource on both request and response. Missing, invalid or contradictory type evidence remains finite-or-unknown, blocking drain while outstanding. The guard no longer falls back from response to request type.

Three additional negative replays cover Fetch initiation with EventSource response, missing response type, and invalid response type. All three syntax checks and the isolated pure replay suite passed again:

```text
Passed 29 semantic replays plus privacy, body, budget, four-target and sink controls.
```

No product, browser, server, benchmark or soak was run for this correction. Scope and acceptance limits remain unchanged.

| Type-consistency revision reviewed before deadline fix (superseded below) | SHA-256 |
|---|---|
| ledger.mjs (173 lines) | c8e85f410f98117a5e769f8f3a4d32009810bd9c4434c5acd13e31b7330b6096 |
| README.md | 33c637edad2cbd77d3fb50a46be4c2d830a5abac127407e403b5a212bde5b21b |
| replays.mjs | d36f80c231760516645c38ef1e60143953a5034e0ecb8a0dd3c489069bcd4898 |
| selftest.mjs | 80aa49632ed7f7638a84daa23bf8d5ddf2fe32297f64047d0ffcb6fdfaa3208d |

## Irreversible deadline decision

Root identified another false acceptance while planning a protocol control: a request active at its frozen deadline could finish later and a subsequent call would return drained. The collector now irreversibly latches `deadlineMissed`. A later fault-free empty transport set is reported as `currentlyDrained:true` while status remains `not-drained` for that missed checkpoint. First observation only after the deadline cannot establish on-time verification, even when empty. New requests invalidate earlier quiet verification and require a fresh on-time observation. Finite addition of start and budget is validated; there is no new SLO or implicit budget.

Three additional pure controls verify waiting -> not-drained at deadline -> late finish -> still not-drained; first-call-late/empty; and earlier quiet verification followed by new work whose completion is only observed late. All syntax checks and the same 29 semantic replay fixtures plus additional controls passed. No product, browser, server, benchmark or soak ran.

| Current file | SHA-256 |
|---|---|
| ledger.mjs (179 lines) | 5bad0bff91320fb3ebba510de124bdb98e611d8c1cda4de85e8fb9c9e2fd60c3 |
| README.md | b577082030602a4c6f719aa21433c7074412dac4c226ca758e36e342ac36ac0a |
| replays.mjs | d36f80c231760516645c38ef1e60143953a5034e0ecb8a0dd3c489069bcd4898 |
| selftest.mjs | 78175a5d12a09d88f41d9ae87b6320662d1d831d55cba983587c70e758ebd091 |

Next action: independent static re-review and tiny replay verification of these exact files. Do not integrate into or execute a final full-provider soak from this receipt alone.

# Independent overlay-ledger review

Static source inspection only,2026-10-22. No controls rerun, application/browser/service/profile/benchmark or GitHub action; candidate unchanged. Reviewed ledger, README, contract-receipt, hashes, overlay-selftest and original diff. Candidate ledger SHA256 independently verified `2f7ede8274b2bd3395fc83bf21890b3edfa5c03860f37e85663a19023d26c606`. Original remains `5bad0bff91320fb3ebba510de124bdb98e611d8c1cda4de85e8fb9c9e2fd60c3`.

## Finding: strict declared-session coverage can be skipped

**[P2, test-only collector]** `network-ledger-overlay/ledger.mjs:17-35` permits multiple contracts for distinct sessions on the SAME target (same role). `:191` reduces observed ready sessions to a SET OF TARGETS; `:218` drain coverage tests only distinct target count, not every frozen target/session contract. A declared expected session can therefore be absent without blocking drain.

Concrete source-derived counterexample, NOT executed: expectedTargets1, two valid overlay contracts(targetO,sessionA) and(targetO,sessionB),capacity1 each. Attach+enable only sessionA, optionally observe its valid owned GET/overlay/events Fetch/Fetch200SSEMIME stream, then drain within bounds. Targets1/readyTargets1, no faults and no blocking finite requests means `currentlyDrained=true` at220, even though frozen sessionB was never attached/enabled. This does not let sessionB's observed wrong-scope requests borrow A; it creates an UNOBSERVED declared-session coverage hole. The default one-session-per-page intended adapter avoids this only by an external assumption the strict collector currently permits violating.

Small repair options: for this adapter, reject a second session contract on any target; OR in strict mode require EVERY frozen exact target/session scope to exist, match its contract and be enabled/open before reporting covered drain. The latter retains supported aggregate-capacity scenarios. Missing declared session should be inconclusive, not drained. Add a pure negative control with two contracts/same target but only one attached/enabled; also one attached-but-not-enabled. Do not change default-mode coverage or rebind sessions after measurement begins.

`overlay-selftest.mjs:92` tests aggregate capacity only AFTER both sessions attach through setup's loop; it cannot catch this hole. `:77` tests three different targets, so target-level coverage suffices for that case. No existing positive/negative controls override this static counterexample. Resolve before relying on strict session-coverage acceptance.

## Checks that look correct in source

- Contract rows are exact own-field plain/null-prototype records; target/session primitive bounded strings, exact role/page/method/type/route combinations and safe capacity validated, then primitive copied and frozen(:13-36). Caller object/array mutation cannot broaden accepted fields. Duplicate exact target/session pairs and contradictory target roles reject.
- Attach maps exact frozen pair and role/targetType at104-106. Unknown/mismatched attach faults permanently and never installs a stream contract. Request stream contract is copied from that session at143; later event role declarations cannot broaden it. Request before enabled faults coverage. Session close remains permanent coverage-closed; no close-as-success shortcut.
- Strict exemption at169-172 requires stored exact scope contract, owned origin,GET,reviewed path, primitive matching request+response type, primitive SSEMIME normalization and integer2xx. Missing/boxed/coerced type/status/MIME, POST, external same path and other routes remain blocking or inconclusive. Native EventSource is not synthesized from Fetch. Legacy route options do not broaden strict exemption.
- Drain207-216 enforces both per-contract and aggregate per-target capacity among open expected streams; overcapacity is blocking. A stream must receive valid header evidence before exemption. Terminal failure/cancellation can settle transport but proves no product success.
- No diff to persistence emit/backpressure logic, sanitized fixed rows, request/redirect/body association, time barriers, fault permanence or irreversible deadline calculation. Strict adds only local cN contract tags, not raw caller IDs. Default mode branches are unchanged aside from null-contract scaffolding; same default sanitized rows/verdict logic remains.

## Test evidence assessment and boundary

Author receipt reports29 original semantic replays plus original extra controls,29 default differential replays and76 strict controls passed under Node24.20.0. This review did NOT independently execute or certify their pass status. Source verifies actual controls cover type-pair permutations, origin/route/method/status/MIME, unknown target/session and attach mismatch, target coverage/privacy, per-contract/aggregate capacity, copied-contract mutation, malformed contracts,sink refusal and latched deadline. Differential loop deep-compares lines/snapshot/drain against original for each replay(:36-46). Original replays and selftest bytes independently hash-identical to copies. The missing declared-session controls above are absent.

Attaching exact role/page/session metadata is still an ADAPTER DECLARATION, not independent observed browser-role evidence. Listener attachment and Network.enable acknowledgment must occur before first navigation on every actual target/session; the collector cannot detect traffic that an adapter never forwards. Freeze mappings from actual target/session creation; never manufacture role/type evidence to fit contracts.

Actual overlay Fetch/Fetch CDP classification remains UNVERIFIED. Source streaming fetch supports API/route distinction only; the candidate's type pair is a hypothesis. No runtime transport, persistent sink adapter, application body-consumption join, soak, resource budget or acceptance gate is green from these pure controls. Preserve any actual mismatch and fail closed rather than revise the contract after seeing a failing run.

Decision: one concrete strict-session coverage repair needed; otherwise the optional route/type/role/capacity boundary is appropriately narrow in inspected source. Candidate is NOT ready as a runtime or final-soak acceptance claim.

## Resolution recheck

Static-only recheck of revised ledger SHA256 `2bd14431eac9114b37ae7a19793dfa94a3d3288dd3a64e8865ac8363c859febe`; candidate.patch SHA256 `a599d7b2a12a98a456c8d0130e072f13042183dc140022063724d36b2e9167d2`, both independently hashed. Initial candidate and evidence are preserved under network-ledger-overlay/review-initial. No tests or runtime workloads rerun.

**Original finding resolved for the declared one-session-per-page adapter.** Constructor line31 now rejects ANY second contract with the same target, regardless of session/role. Combined with exact frozen target/session attach matching and required distinct target count, a declared but unobserved scope can no longer hide behind another ready session on the same target. Unknown/rebound sessions still fault; no dynamic session coverage was added. The diff changes only this constructor condition/error in the collector; privacy,sink,capacity and deadline paths remain unchanged.

Revised overlay-selftest includes explicit same-target/different-session constructor rejection and missing-declared-page drain inconclusive controls near92-105. The reported29 original+29default differential+77strict pass counts remain author evidence, not independently rerun here. No new concrete defect identified in this tiny delta. Actual browser Fetch/Fetch classification, adapter persistence/coverage and runtime/soak conformance remain UNVERIFIED; this resolution is not runtime acceptance.
